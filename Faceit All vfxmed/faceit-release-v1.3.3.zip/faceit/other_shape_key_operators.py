import bpy
import json
import numpy as np
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata


class FACEIT_OT_GenerateTestAction(bpy.types.Operator):
    '''Generate a new Test Action to see all Shape Keys'''
    bl_idname = 'faceit.test_action'
    bl_label = 'Generate Test Action'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            obj = futils.get_object(context.scene.faceit_object_name)
            if obj:
                if obj.data.shape_keys:
                    return True

    def execute(self, context):
        print('Start Test Action...')

        scene = context.scene

        face_objects = futils.get_faceit_objects_list()

        test_action = bpy.data.actions.get('faceit_bake_test_action')

        if test_action:
            bpy.data.actions.remove(test_action)

        test_action = bpy.data.actions.new(name='faceit_bake_test_action')

        for obj in face_objects:
            # deselect all
            shape_keys = obj.data.shape_keys
            if not shape_keys:
                continue

            if not shape_keys.animation_data:
                shape_keys.animation_data_create()

            shape_keys.animation_data.action = test_action

            shape_keys = shape_keys.key_blocks

            for i, sk in enumerate(shape_keys):
                if sk.name == 'Basis':
                    continue
                frame = i * 10

                sk.value = 0
                sk.keyframe_insert(data_path='value', frame=frame - 9)
                sk.keyframe_insert(data_path='value', frame=frame + 1)
                sk.value = 1
                sk.keyframe_insert(data_path='value', frame=frame)
                sk.value = 0
        scene.frame_start = 1
        scene.frame_end = 520

        return{'FINISHED'}


class FACEIT_OT_TransferShapeKeys(bpy.types.Operator):
    '''For Rigged Characters... Transfer all Shape Keys from selected to active.'''
    bl_idname = 'faceit.transfer_shape_keys'
    bl_label = 'Transfer Shape Keys'
    bl_options = {'UNDO'}

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            if len(context.selected_objects) == 2:
                return True

    def execute(self, context):
        scene = context.scene

        def store_shape_keys(obj):
            ''' Store all shapekeys data in numpy arrays for @obj'''
            vert_count = len(obj.data.vertices)
            sk_dict = {}
            for sk in obj.data.shape_keys.key_blocks[1:]:
                # numpy array with shapekey data
                sk_data = np.zeros(vert_count*3, dtype=np.float32)
                sk.data.foreach_get('co', sk_data.ravel())

                sk_dict[sk.name] = sk_data
            return sk_dict

        def apply_stored_shape_keys(obj, sk_dict):
            ''' Apply the saved shapekey data from @sk_dict to objects shapekeys in new order from @export_order_dict '''
            # The new index for the shapekey with name shapekey_name
            for shapekey_name, sk_data in sk_dict.items():
                # the new shapekey
                new_sk = obj.shape_key_add(name=shapekey_name)
                new_sk.data.foreach_set('co', sk_data.ravel())

        active_obj = context.view_layer.objects.active
        selected_obj = [obj for obj in context.selected_objects if obj is not active_obj][0]

        # check if both objects are meshes
        if not (active_obj.type == 'MESH' and selected_obj.type == 'MESH'):
            self.report({'ERROR'}, 'You can only transfer Shape Keys between Meshes.')
            return{'CANCELLED'}

        if not len(active_obj.data.vertices) == len(selected_obj.data.vertices):
            self.report({'ERROR'}, 'Both objects need the same Vertex Count to Transfer Shape Keys..')
            return{'CANCELLED'}

        if not selected_obj.data.shape_keys:
            self.report({'ERROR'}, 'No Shape Keys found on selected object.')
            return{'CANCELLED'}

        if scene.faceit_overwrite_shape_keys_on_transfer:
            active_obj.shape_key_clear()

        # Copy Shape Keys from active to selected objects...
        sk_dict = store_shape_keys(selected_obj)

        if not active_obj.data.shape_keys:
            active_obj.shape_key_add(name='Basis')

        self.report({'INFO'}, 'transfer sk from {} to {}'.format(selected_obj.name, active_obj.name))

        apply_stored_shape_keys(active_obj, sk_dict)

        return {'FINISHED'}


class FACEIT_OT_RenameKeys(bpy.types.Operator):
    '''Rename Shape Keys to Face Cap naming'''
    bl_idname = 'faceit.rename_keys'
    bl_label = 'Rename Shapekeys'
    bl_options = {'UNDO', 'INTERNAL'}

    target_platform: bpy.props.StringProperty(
        name='Capturing Engine',
        default='',
        options={'HIDDEN', }
    )

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            return True

    def execute(self, context):
        scene = context.scene

        target_platform = 'FACECAP'
        expression_file = fdata.get_expressions_file()
        bpy.ops.faceit.reorder_keys('EXEC_DEFAULT', target_platform=target_platform, keep_motion=True)

        def get_names():
            with open(expression_file) as f:
                data = json.load(f)
                # Export order dictionary
                expression_names = data[target_platform]['Names']
                return expression_names

        expression_names = get_names()

        faceit_objects = futils.get_faceit_objects_list()

        for obj in faceit_objects:

            shape_keys = obj.data.shape_keys

            if not shape_keys:
                self.report({'WARNING'}, 'No shapekeys found for object {}'.format(obj.name))
                continue

            shapekeys = obj.data.shape_keys.key_blocks

            i = 0
            for sk in shapekeys:
                if sk.name == 'Basis':
                    continue

                new_name = expression_names[i]
                # if new_name != sk.name:
                sk.name = 'shapes.'+new_name
                i += 1
                # if i == len(shapekeys)

        return{'FINISHED'}


class FACEIT_OT_ReorderKeys(bpy.types.Operator):
    '''Reorder Shape Key Indices to the specified order. This operator is slow when Shape Key values are driven with Drivers'''
    bl_idname = 'faceit.reorder_keys'
    bl_label = 'Reorder Shapekeys'
    bl_options = {'UNDO', 'INTERNAL'}

    target_platform: bpy.props.StringProperty(
        name='Capturing Engine',
        default='',
        options={'HIDDEN', }
    )

    keep_motion: bpy.props.BoolProperty(
        name='Keep Motion Applied',
        default=False,
    )

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            return True

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene

        def read_order(export_order_file):

            target_platform = self.target_platform or scene.faceit_target_platform

            with open(export_order_file) as f:
                data = json.load(f)
                # Export order dictionary
                export_order_dict = data[target_platform]['Indices']
                # increment all indices, so Basis stays untouched
                for sk in export_order_dict.keys():
                    export_order_dict[sk] += 1

                return export_order_dict

        def store_shape_keys(obj):
            ''' Store all shapekeys data in numpy arrays for @obj'''
            vert_count = len(obj.data.vertices)
            sk_dict = {}
            for sk in obj.data.shape_keys.key_blocks[1:]:
                # numpy array with shapekey data
                sk_data = np.zeros(vert_count*3, dtype=np.float32)
                sk.data.foreach_get('co', sk_data.ravel())

                sk_dict[sk.name] = sk_data
            return sk_dict

        def apply_stored_shape_keys(shapekeys, sk_dict, export_order_dict):
            ''' Apply the saved shapekey data from @sk_dict to objects shapekeys in new order from @export_order_dict '''
            # The new index for the shapekey with name shapekey_name
            for shapekey_name, new_index in export_order_dict.items():
                # the new shapekey
                new_sk = shapekeys[new_index]
                # find the index of old shapekey
                sk_data = sk_dict[shapekey_name]
                new_sk.data.foreach_set('co', sk_data.ravel())
                new_sk.name = '_temp'
                new_sk.value = 0

        def store_properties(shapekeys):
            sk_properties = {}

            for sk in shapekeys:
                sk_properties[sk.name] = {
                    "name": sk.name,
                    "mute": sk.mute,
                    "vertex_group": sk.vertex_group,
                    "relative_key": sk.relative_key,
                    "slider_min": sk.slider_min,
                    "slider_max": sk.slider_max,
                }
            return sk_properties

        def restore_properties(shapekeys, export_order_dict, sk_props):

            for shapekey_name, new_index in export_order_dict.items():
                # the new shapekey
                new_sk = shapekeys[new_index]

                props = sk_props[shapekey_name]

                new_sk.name = props['name']
                # new_sk.value = props['value']
                new_sk.mute = props['mute']
                new_sk.vertex_group = props['vertex_group']
                new_sk.relative_key = props['relative_key']
                new_sk.slider_min = props['slider_min']
                new_sk.slider_max = props['slider_max']

        def reorder_slow(ob, shapekeys, export_order_dict):

            for shapekey_name, new_index in export_order_dict.items():
                # find the index of shapekey
                index = shapekeys.find(shapekey_name)
                sk = shapekeys.get(shapekey_name)
                sk.value = 0

                ob.active_shape_key_index = index
                # move the shapekey to the new index
                for _ in range(index-new_index):
                    # {'active_object': ob, 'selected_objects': []}
                    bpy.ops.object.shape_key_move(type='UP')

        export_order_dict = read_order(fdata.get_expressions_file())

        faceit_objects = futils.get_faceit_objects_list()

        reordered = False
        order_exists = False

        action_to_keep = None

        for obj in faceit_objects:

            reorder_with_driver = False

            shape_keys = obj.data.shape_keys

            if not shape_keys:
                self.report({'WARNING'}, 'No shapekeys found for object {}'.format(obj.name))
                continue

            if self.keep_motion and action_to_keep is None:
                try:
                    action_to_keep = obj.data.shape_keys.animation_data.action
                except:
                    pass

            shapekeys = obj.data.shape_keys.key_blocks

            if all([shapekeys[index].name == shapekey_name for shapekey_name, index in export_order_dict.items()]):
                order_exists = True
                continue

            # animation_data_stored[obj] = anim_data = shape_keys.animation_data
            if not shape_keys.animation_data:
                shape_keys.animation_data_create()
            else:
                if len(shape_keys.animation_data.drivers) > 0:
                    reorder_with_driver = True

            # Clear the active action from data before reordering, so the fcurves don't get messed up.
            shape_keys.animation_data.action = None

            if reorder_with_driver:

                futils.clear_object_selection()
                futils.set_active_object(obj.name)
                reorder_slow(obj, shapekeys, export_order_dict)

            else:

                # Store the shapekeys data in numpy arrays
                sk_data_dict = store_shape_keys(obj)
                # temporarilly store the props (name, vertex_groups etc..)
                sk_props = store_properties(shapekeys)
                # apply the stored data to the new index
                apply_stored_shape_keys(shapekeys, sk_data_dict, export_order_dict)
                # change the new shapekeys properties
                restore_properties(shapekeys, export_order_dict, sk_props)

            reordered = True

        if self.keep_motion and action_to_keep is not None:
            for obj in faceit_objects:
                shape_keys = obj.data.shape_keys
                if not shape_keys:
                    continue
                # Reset Animation values
                for sk in shape_keys.key_blocks:
                    sk.value = 0

                shape_keys.animation_data.action = action_to_keep

        if order_exists:
            self.report({'INFO'}, 'Order already applied for all objects')
            return{'CANCELLED'}

        if not reordered:
            self.report({'WARNING'}, 'Failed! Did you create Shapekeys? Did you register the Objects?')
            return{'CANCELLED'}

        expression_list = scene.faceit_expression_list

        for i, expression in enumerate(expression_list):
            expression.name = obj.data.shape_keys.key_blocks[i + 1].name

        return{'FINISHED'}
