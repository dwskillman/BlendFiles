import os
import bpy
import csv
import numpy as np
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata


class MocapLoadFromText():
    '''This class bundles utility functions to read and populate Text or CSV mocap data to the registered objects.'''

    shape_key_animation_values = []
    head_location_animation_values = []
    head_rotation_animation_values = []
    eye_L_rotation_animation_values = []
    eye_R_rotation_animation_values = []
    frames = []
    frame_count = 0

    def __init__(
            self, filename, mocap_engine, fps, frame_start, laod_sk, load_head_rot, load_head_loc, load_eye_rot, action,
            overwrite_action):
        self.filename = filename
        self.framerate = fps
        self.mocap_engine = mocap_engine
        self.frame_start = frame_start
        self.read_shapekeys = laod_sk
        self.read_head_rotation = load_head_rot
        self.read_head_location = load_head_loc
        self.read_eye_rotation = load_eye_rot
        self.action = action
        self.overwrite_action = overwrite_action
        self.read_mocap()

    def get_frame_count(self):
        return len(self.frames)

    def convert_timecode_to_frames(self, timecode, start=None):
        '''This function converts an SMPTE timecode into frames
        @timecode [str]: format hh:mm:ss:ff
        @start [str]: optional timecode to start at
        '''
        # recording fps
        recorded_framerate = 1/60

        def _seconds(value):
            '''convert value to seconds
            @value [str, int, float]: either timecode or frames
            '''
            if isinstance(value, str):  # value seems to be a timestamp
                _zip_ft = zip((3600, 60, 1, recorded_framerate), value.split(':'))
                return sum(f * float(t) for f, t in _zip_ft)
            elif isinstance(value, (int, float)):  # frames
                return value / self.framerate
            else:
                return 0

        def _frames(seconds):
            '''convert seconds to frames
            @seconds [int]: the number of seconds 
            '''
            return seconds * self.framerate

        return _frames(_seconds(timecode) - _seconds(start))

    def read_mocap(self):
        '''returns all animation values set by user in individual lists'''
        # frames = timecodes
        frames = []
        # values ordered as shapekey indices as lists i.g. [0.00, 0.00, 0.01, 0.02...]
        shape_key_animation_values = []
        head_rotation = []
        head_location = []
        eye_L = []
        eye_R = []
        first_frame = 0
        with open(self.filename) as csvfile:
            reader = csv.reader(csvfile)
            if self.mocap_engine == 'UE':
                for i, row in enumerate(reader):
                    if i == 0:
                        continue
                    if i == 1:
                        first_frame = self.convert_timecode_to_frames(row[0]) - self.frame_start

                    frames.append(self.convert_timecode_to_frames(row[0]) - first_frame)
                    # Head Motion
                    if self.read_head_rotation:
                        head_rotation.append([float(v) for v in row[54:57]])
                    # Eyes Motion
                    if self.read_eye_rotation:
                        eye_L.append([float(v) for v in row[58:60]])
                        eye_R.append([float(v) for v in row[60:62]])
                    # Blendshapes Motion
                    if self.read_shapekeys:
                        shape_key_animation_values.append([float(v) for v in row[2:54]])

            elif self.mocap_engine == 'FC':
                for row in reader:
                    if row[0] != 'k':
                        continue
                    # Nano seconds since last frame
                    current_frame = self.frame_start + (float(row[1])/1000) * self.framerate
                    frames.append(current_frame)
                    # Head Motion
                    if self.read_head_location:
                        head_location.append([float(v) for v in row[2:5]])
                    if self.read_head_rotation:
                        head_rotation.append(np.radians([float(v) for v in row[5:8]]))
                    # Eyes Motion
                    if self.read_eye_rotation:
                        eye_L.append(np.radians([float(v) for v in row[8:10]]))
                        eye_R.append(np.radians([float(v) for v in row[10:12]]))
                    # Blendshapes Motion
                    if self.read_shapekeys:
                        shape_key_animation_values.append([float(v) for v in row[12:]])

        # return frames, shape_key_animation_values, head_location, head_rotation, eye_L, eye_R
        self.frames = frames
        self.frame_count = len(frames)
        self.shape_key_animation_values = shape_key_animation_values
        self.head_location_animation_values = head_location
        self.head_rotation_animation_values = head_rotation
        self.eye_L_rotation_animation_values = eye_L
        self.eye_R_rotation_animation_values = eye_R

    def get_values_for_animation(self, animation_values, index):
        '''Returns list with the respective captured values per frame'''
        values = []
        if animation_values:
            for j in range(self.frame_count):
                if len(animation_values[j]) > 1:
                    values.append(animation_values[j][index])
                else:
                    values.append(0)
        return values

    def get_kf_data_from_fcurve(self, fc):
        '''
        Returns the animation from an fcurve in a numpy array
        '''
        # Store existing keyframes in array
        kf_points = fc.keyframe_points
        kf_count = len(kf_points)

        # Create a 1D Numpy array to hold all co(x,y) attrs of keyframepoints
        kf_data = np.zeros(kf_count*2, dtype=np.float32)
        fc.keyframe_points.foreach_get('co', kf_data)
        # Reshape to 2Darray -> tuple style like co
        kf_data = np.reshape(kf_data, (-1, 2))
        return kf_data

    def populate_data_to_fcurve(self, values, dp, array_index=None, action=None):
        '''
        Populates the captured data into the individual actions (shapekeys, head, eye_L, eye_R)
        @action: the action to hold the new motion
        @frames: the number of frames
        @values: the values for that particular fcurve
        @fc: the fcurve
        @dp: the datapath
        @index: (optional) array index of location/rotation values
        '''
        action = action or self.action

        if array_index is not None:
            fc = action.fcurves.find(dp, index=array_index)
        else:
            fc = action.fcurves.find(dp)
        # New Fcurve either becuase
        # the fc does not exist or overwrite_action is true
        if not fc or self.overwrite_action:

            if fc:
                action.fcurves.remove(fc)

            if array_index:
                fc = action.fcurves.new(dp, index=array_index)
            else:
                fc = action.fcurves.new(dp)

            # Create new keyframe points and populate captured values
            fc.keyframe_points.add(count=len(values))
            fc.keyframe_points.foreach_set('co', [x for co in zip(self.frames, values) for x in co])

        else:
            # Store animation in fcurve into a numpy array
            kf_data = self.get_kf_data_from_fcurve(fc)

            # Remove all keyframes from fcurve by deleting and recreating it
            action.fcurves.remove(fc)
            if array_index:
                fc = action.fcurves.new(dp, index=array_index)
            else:
                fc = action.fcurves.new(dp)

            # Store captured values in another 1D array
            mocap_keyframe_points = list(zip(self.frames, values))
            mocap_kf_data = np.array(mocap_keyframe_points, dtype=np.float32)

            # Remove all keyframes that intersect with new mocap
            mask = ((kf_data < min(self.frames)) | (kf_data > max(self.frames))).all(axis=1)
            kf_data = kf_data[mask, :]

            final_kf_data = np.append(kf_data, mocap_kf_data, 0)

            fc.keyframe_points.add(count=final_kf_data.size / 2)
            fc.keyframe_points.foreach_set('co', [x for co in final_kf_data for x in co])

        fc.update()

    def populate_shape_key_motion_data_to_fcurve(self, sk_name, sk_index):
        '''populate the shape key motion data into fcurves
        @sk_name [string]: the name of the shapekey
        @sk_index [int]: the index of the shapekey
        '''

        values = self.get_values_for_animation(self.shape_key_animation_values, sk_index)

        dp = 'key_blocks["{}"].value'.format(sk_name)

        self.populate_data_to_fcurve(values, dp)

    def populate_object_transform_motion_data_to_fcurve(
            self, action, part, dp, channels_count, reroute_channels_matrix=None, scale_channels_vector=None,
            invert_values=False):
        '''Populate the motion data into fcurves for each channel of a transform object.
        @part [string]: the part to animate - either eye L, R or head loc, rot
        @action [action id]: the action that should hold or holds the fcurves
        @dp [string]: the data_path of the fcurve (e.g. rotation_euler)
        @channels_count [int]: the number of channels that should be retargeted (e.g. 2 for x/y rotation) 
        @reroute_channels_matrix [dict]: A ditionary that maps indices (e.g. to change rotation order)
        @scale_channels_vector [list]: A vector that holds multipliers for each channel (e.g. to negate a value)
        '''
        animation_values = None
        if part == 'head_loc':
            animation_values = self.head_location_animation_values
        if part == 'head_rot':
            animation_values = self.head_rotation_animation_values
        if part == 'eye_L':
            animation_values = self.eye_L_rotation_animation_values
        if part == 'eye_R':
            animation_values = self.eye_R_rotation_animation_values

        if animation_values:

            for i in range(channels_count):

                # indices for XYZ location - reroute YZ
                if reroute_channels_matrix is not None:
                    array_index = reroute_channels_matrix[i]
                else:
                    array_index = i

                values = self.get_values_for_animation(animation_values, index=i)

                if scale_channels_vector:
                    # Scale compensation for unit differences
                    values = np.array(values) * scale_channels_vector[i]

                self.populate_data_to_fcurve(values, dp, array_index=array_index, action=action)


class FACEIT_OT_ImportMocap(bpy.types.Operator):
    '''Import raw mocap data from text or csv files'''
    bl_idname = 'faceit.import_mocap'
    bl_label = 'Import'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    engine: bpy.props.EnumProperty(
        name='mocap engine',
        items=(
            ('FC', 'Face Cap', 'Face Cap TXT'),
            ('UE', 'Live Link Face', 'Live Link Face CSV'),
        ),
    )

    action_name: bpy.props.StringProperty(
        name='Action',
    )

    new_action: bpy.props.BoolProperty(
        name='Create a new Action',
        options={'HIDDEN'}
    )

    overwrite_action: bpy.props.BoolProperty(
        name='Overwrite existing Animation',
        default=False
    )

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            return len(context.scene.faceit_face_objects) >= 1

    def invoke(self, context, event):
        engine_settings = fdata.get_engine_settings(self.engine)
        self.new_action = engine_settings.load_to_new_action
        wm = context.window_manager

        if self.new_action:
            # self.filename = self.get_mocap_filename()
            # self.filename.split('\\')[-1].strip('.txt')
            self.action_name = self.get_clean_filename(engine_settings.filename)
        return wm.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        if self.new_action:
            row.prop(self, 'action_name')
        else:
            row.prop(self, 'overwrite_action')

    def check_file_path(self, filename):
        '''Returns True when filename is valid'''
        if not filename or not os.path.exists(filename) or not os.path.isfile(filename):
            return False
        return True

    def get_clean_filename(self, filename):
        '''Returns the string filename - strips directories and file extension'''
        return (filename.split('\\')[-1]).split('.')[0]  # .strip('.{}'.format(file_extension))

    def get_action(self, action_name):
        '''
        Get an action by name, create it if it does not exist
        '''
        action = bpy.data.actions.get(action_name)
        if not action:
            self.report({'INFO'}, 'Creating new Action with name {}'.format(action_name))
            action = bpy.data.actions.new(name=action_name)
        return action

    def execute(self, context):

        scene = context.scene
        engine_settings = fdata.get_engine_settings(self.engine)

        # Create the new Action
        if self.new_action:
            bpy.ops.faceit.new_action('EXEC_DEFAULT', action_name=self.action_name, populate_animation_data=True)
            engine_settings.load_to_new_action = False

        mocap_action = scene.faceit_mocap_action
        if not mocap_action:
            self.report({'WARNING'}, 'You should populate/activate an Action before importing captured motions')
            return({'CANCELLED'})

        # Populate the Action to all registered objects
        bpy.ops.faceit.populate_action()

        # frame_start = fdata.mocap_engine_settings[self.engine]['frame_start']
        if scene.faceit_auto_reordering:
            bpy.ops.faceit.reorder_keys('EXEC_DEFAULT', target_platform=engine_settings.indices_order, keep_motion=True)
        frame_start = engine_settings.frame_start

        scene_framerate = scene.render.fps

        laod_sk, load_head_rot, load_head_loc, load_eye_rot = \
            scene.faceit_mocap_motion_types.read_settings()
        if not (laod_sk or load_head_rot or load_head_loc or load_eye_rot):
            self.report({'ERROR'}, 'You have to choose wich type of motion you want to import')
            return {'CANCELLED'}

        filename = engine_settings.filename  # self.get_mocap_filename()
        if not self.check_file_path(filename):
            self.report({'ERROR'}, 'Mocap File not set or invalid')
            return {'CANCELLED'}

        mocap_loaded = MocapLoadFromText(
            filename, self.engine, scene_framerate, frame_start, laod_sk, load_head_rot, load_head_loc, load_eye_rot,
            action=mocap_action, overwrite_action=self.overwrite_action)

        new_frame_range = None

        # Populate actions to registered objects with Shape Keys.
        if laod_sk:

            # Any object with the required Shape Keys
            object_with_shape_keys = None

            face_objects = futils.get_faceit_objects_list()

            for obj in face_objects:

                shapekeys = obj.data.shape_keys

                if not shapekeys:
                    self.report({'WARNING'}, 'Object {} contains no Shape Keys'.format(obj.name))
                    continue

                # Initialize template and blendshapes action to hold the mocap values.
                if not object_with_shape_keys:
                    object_with_shape_keys = obj

                if not shapekeys.animation_data:
                    shapekeys.animation_data_create()

            # Populate the Shape Key action with mocap values
            if object_with_shape_keys:

                keyblocks = object_with_shape_keys.data.shape_keys.key_blocks

                # Skip Basis key
                for i, key in enumerate(keyblocks[1:]):
                    mocap_loaded.populate_shape_key_motion_data_to_fcurve(sk_name=key.name, sk_index=i)
            else:
                self.report({'WARNING'}, 'None of the registered objects holds Shape Keys. No Mocap Action created')

            new_frame_range = mocap_action.frame_range

        # Create new Actions for rotation/location targets with suffixes
        action_prefix = mocap_action.name

        if (load_head_loc or load_head_rot):
            # the rotation/location objects set by user
            head_empty = futils.get_object(scene.faceit_mocap_target_head)

            if head_empty:
                # Populate the head motion action with mocap values
                head_action = self.get_action(action_prefix + '_head')

                if not head_empty.animation_data:
                    head_empty.animation_data_create()

                head_empty.animation_data.action = head_action

                # Yaw Pitch Roll
                reroute_UE = {
                    0: 2,
                    1: 0,
                    2: 1,
                }

                reroute_FC = {
                    0: 0,
                    1: 2,
                    2: 1,
                }

                scale_rotation_vec_UE = [
                    1,
                    -1,
                    1,
                ]

                if self.engine == 'FC':
                    reroute_matrix = reroute_FC
                    scale_rotation_vec = None
                else:
                    reroute_matrix = reroute_UE
                    scale_rotation_vec = scale_rotation_vec_UE

                # Head Rotation
                if load_head_rot:

                    mocap_loaded.populate_object_transform_motion_data_to_fcurve(
                        head_action,
                        part='head_rot',
                        dp='rotation_euler',
                        channels_count=3,
                        reroute_channels_matrix=reroute_matrix,
                        scale_channels_vector=scale_rotation_vec

                    )
                if load_head_loc and self.engine != 'UE':

                    # negate Y values
                    # scale_value = 0.01
                    # if i == 1:
                    # 	scale_value = scale_value * -1

                    scale_location_values_vec = [
                        .01,
                        -.01,
                        .01,
                    ]
                    mocap_loaded.populate_object_transform_motion_data_to_fcurve(
                        head_action,
                        part='head_loc',
                        dp='location',
                        channels_count=3,
                        reroute_channels_matrix=reroute_matrix,
                        scale_channels_vector=scale_location_values_vec
                    )

                new_frame_range = head_action.frame_range
            else:
                self.report({'WARNING'}, 'You did not specify a target for head motion')

        if load_eye_rot:

            eye_L_empty = futils.get_object(scene.faceit_mocap_target_eye_l)
            eye_R_empty = futils.get_object(scene.faceit_mocap_target_eye_r)

            reroute_YZ = {
                0: 0,
                1: 2,
            }

            if eye_L_empty:

                eye_L_action = self.get_action(action_prefix + '_eye_L')

                if not eye_L_empty.animation_data:
                    eye_L_empty.animation_data_create()

                eye_L_empty.animation_data.action = eye_L_action

                mocap_loaded.populate_object_transform_motion_data_to_fcurve(
                    eye_L_action,
                    part='eye_L',
                    dp='rotation_euler',
                    channels_count=2,
                    reroute_channels_matrix=reroute_YZ,
                )
                new_frame_range = eye_L_action.frame_range

            else:
                self.report({'WARNING'}, 'You did not specify a target for Left Eye motion')

            if eye_R_empty:

                eye_R_action = self.get_action(action_prefix + '_eye_R')

                if not eye_R_empty.animation_data:
                    eye_R_empty.animation_data_create()

                eye_R_empty.animation_data.action = eye_R_action

                mocap_loaded.populate_object_transform_motion_data_to_fcurve(
                    eye_R_action,
                    part='eye_R',
                    dp='rotation_euler',
                    channels_count=2,
                    reroute_channels_matrix=reroute_YZ,
                )

                new_frame_range = eye_R_action.frame_range

            else:
                self.report({'WARNING'}, 'You did not specify a target for Left Eye motion')

        if new_frame_range:
            scene.frame_start = scene.frame_current = new_frame_range[0]
            scene.frame_end = new_frame_range[1]
            engine_settings.load_to_new_action = False
            scene.frame_current = frame_start
        else:
            self.report({'ERROR'}, 'No motion imported. Did you setup the correct targets?')

        return{'FINISHED'}


class FACEIT_OT_RetargetMotion(bpy.types.Operator):
    '''Choose a catured file to import as keyframes'''
    bl_idname = 'faceit.transfer_shape_key_motion'
    bl_label = 'Load mocap'
    bl_options = {'UNDO', 'INTERNAL'}


class OpenFile(bpy.types.Operator):
    '''Choose a catured file to import as keyframes'''
    bl_idname = 'faceit.custom_path'
    bl_label = 'Load mocap'
    bl_options = {'UNDO', 'INTERNAL'}

    engine: bpy.props.EnumProperty(
        name='mocap engine',
        items=(
            ('FC', 'Face Cap', 'Face Cap TXT'),
            ('UE', 'Live Link Face', 'Live Link Face CSV'),
        ),
    )

    filter_glob: bpy.props.StringProperty(
        default='*.txt',
        options={'HIDDEN'}
    )

    filepath: bpy.props.StringProperty(
        name='File Path',
        description='Filepath used for importing txt files',
        maxlen=1024,
        default='',
    )

    files: bpy.props.CollectionProperty(
        name='File Path',
        type=bpy.types.OperatorFileListElement,
    )

    def execute(self, context):

        fdata.get_engine_settings(self.engine).filename = self.filepath

        # Update UI
        for region in context.area.regions:
            if region.type == "UI":
                region.tag_redraw()
        return {'FINISHED'}

    def invoke(self, context, event):

        if self.engine == 'FC':
            self.filter_glob = '*.txt'
        elif self.engine == 'UE':
            self.filter_glob = '*.csv'

        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
