import re
import bpy
from addon_utils import check
from . import faceit_utils as futils


class ANIM_UL_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            if not bpy.context.scene.faceit_shapes_generated:
                row = layout.row(align=True)
                scene = context.scene
                if item.name != 'mouthClose':
                    # icon_value=510)  # icon:int -> 17 = 'DOT'
                    row.prop(item, 'name', text='', emboss=False, icon='KEYFRAME')
                else:
                    row.label(text="{} (Do Not Edit)".format(item.name), translate=True, icon='KEYFRAME')
                if scene.faceit_expression_list_index == item.index or scene.faceit_expression_list_options_show_all:
                    if item.mirror_name:
                        op = row.operator('faceit.mirror_overwrite', text='', icon='MOD_MIRROR')
                        op.expression_to_mirror = item.name
                    elif scene.faceit_use_auto_mirror_x:
                        row.label(text='', icon='MOD_MIRROR')

                    op = row.operator('faceit.shape_reset', text='', icon='LOOP_BACK')
                    op.expression_to_reset = item.name

            else:
                layout.prop(item, 'name', text='', emboss=False, icon_value=icon)


class FACE_OBJECTS_UL_list(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        scene = context.scene
        face_objects = scene.faceit_face_objects
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # obj = item.obj_pointer
            part = item.part if item.name != data.faceit_object_name else 'main'
            if part:
                entry = '{} ({})'.format(item.name, part.upper())
            else:
                entry = '{}'.format(item.name)

            custom_icon = 'OUTLINER_OB_MESH'
            row = layout.row(align=True)
            row.label(text=entry, icon=custom_icon)
            # index = getattr(item, 'index', None)
            # if scene.faceit_face_index == (index or scene.faceit_face_objects.find(item.name)):
            if item.warnings and scene.faceit_show_warnings:
                op = row.operator('faceit.face_object_warning', text='', icon='ERROR')
                op.warnings = item.warnings
            index = face_objects.find(item.name)
            if index > 0 or len(face_objects) <= 1:
                op = row.operator('faceit.remove_facial_part', text='', icon='X')
                op.prompt = False
                op.remove_item = item.name

            if item.part == 'main':
                row.label(text='', icon='EVENT_M')

        else:
            layout.alignment = 'CENTER'
            layout.label(text='', icon=custom_icon)


class FACEIT_MT_FaceitObjects(bpy.types.Menu):
    bl_label = "Faceit Register Options"

    def draw(self, context):
        scene = context.scene
        faceit_objects = scene.faceit_face_objects
        face_index = scene.faceit_face_index
        active_item = faceit_objects[face_index]
        layout = self.layout
        row = layout.row(align=True)
        op = row.operator('faceit.set_main_part', text='Set Selected as Main (Face)', icon='EVENT_M')
        op.new_main_object = active_item.name
        op.move_index = True
        if active_item.part == 'main':
            row.enabled = False

        row = layout.row(align=True)
        op = row.operator('faceit.clear_facial_part', text='Clear all Registered Objects', icon='TRASH')
        row = layout.row(align=True)
        web = row.operator('faceit.open_web', text='Duplicate Workaround', icon='QUESTION')
        web.link = 'https://faceit-doc.readthedocs.io/en/latest/workaround/'


def draw_panel_dropdown_expander(layout, data, prop, custom_text):
    layout.prop(data, str(prop), text=custom_text,
                icon='TRIA_DOWN' if data.get(prop) else 'TRIA_RIGHT',
                icon_only=True, emboss=False
                )


def draw_web_link(layout, link, text_ui='', show_always=False):
    '''Draws a Web @link in the given @layout. Optionally with plain @text_ui'''
    if bpy.context.preferences.addons[__package__].preferences.web_links or show_always:
        web = layout.operator('faceit.open_web', text=text_ui, icon='QUESTION')
        web.link = link


def draw_reorder_box(layout, scene):
    # row = layout.row(align=True)
    # row.label(text='Reorder Shapekey Indices')

    row = layout.row(align=True)
    row.prop(scene, 'faceit_auto_reordering', icon='MENU_PANEL')
    if not scene.faceit_auto_reordering:
        row = layout.row(align=True)
        row.prop(scene, 'faceit_target_platform', text='')
        # row.prop(scene, 'faceit_reorder_slow', text='with Drivers (Slow)', icon='DRIVER')
        row.operator('faceit.reorder_keys', icon='SORTSIZE')
        row = layout.row(align=True)
        row.operator('faceit.rename_keys', icon='SORTSIZE')


class FACEIT_PT_Rigging(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'FACEIT'
    bl_label = 'FaceIt'

    def draw(self, context):

        scene = context.scene
        layout = self.layout

        box = layout.box()
        row = box.row()
        draw_panel_dropdown_expander(row, scene, 'faceit_expand_workflow', 'Choose Workflow')

        if scene.faceit_expand_workflow:
            box.row().prop(scene, 'faceit_active_workflow', expand=True, icon='CUBE')

        workflow = scene.faceit_active_workflow

        if workflow == 'RIG':
            # layout.label(text='ARKit Shape Keys')
            layout.row().prop(scene, 'faceit_only_rig_active_tab', expand=True)
            active_tab = scene.faceit_only_rig_active_tab
        elif workflow == 'MOCAP':
            layout.row().prop(scene, 'faceit_only_mocap_active_tab', expand=True)
            active_tab = scene.faceit_only_mocap_active_tab
        elif workflow == 'ALL':
            # layout.label(text='ARKit Shape Keys')
            layout.row().prop(scene, 'faceit_active_tab', expand=True)
            active_tab = scene.faceit_active_tab

        layout.separator()

        face_objects = scene.faceit_face_objects

        ############ SETUP ################
        if active_tab == 'SETUP':
            col = layout.column(align=True)

            row = col.row(align=True)

            row.label(text='Registration')

            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/setup_objects/')

            if face_objects:

                col.separator(factor=1.0)
                row = col.row()
                row.template_list('FACE_OBJECTS_UL_list', '', scene, 'faceit_face_objects', scene, 'faceit_face_index')
                col_ul = row.column(align=True)
                # row.prop(scene, 'faceit_show_warnings', text='', icon='ERROR')

                row = col_ul.row(align=True)
                op = row.operator('faceit.add_facial_part', text='', icon='ADD')

                row = col_ul.row(align=True)
                op = row.operator('faceit.remove_facial_part', text='', icon='REMOVE')
                op.prompt = False

                col_ul.separator()

                row = col_ul.row()
                row.menu('FACEIT_MT_FaceitObjects', text='', icon='DOWNARROW_HLT')

                col_ul.separator()

                row = col_ul.row(align=True)
                op = row.operator('faceit.move_face_object', text='', icon='TRIA_UP')
                op.direction = 'UP'
                row = col_ul.row(align=True)
                op = row.operator('faceit.move_face_object', text='', icon='TRIA_DOWN')
                op.direction = 'DOWN'

                row = col.row(align=True)
                op = row.operator('faceit.add_facial_part', icon='ADD')
                row = col.row(align=True)

                if workflow != 'MOCAP':

                    op = row.operator('faceit.face_object_warning_check', text='Check Geometry', icon='CHECKMARK')
                    op.item_name = 'ALL'
                    op.set_show_warnings = True
                    row = col.row(align=True)
                    icon_hide = 'HIDE_OFF' if scene.faceit_show_warnings else 'HIDE_ON'
                    row.prop(scene, 'faceit_show_warnings', icon=icon_hide)

                    col.separator(factor=3.0)
                    box = col.box()
                    col_edit = box.column(align=True)
                    row = col_edit.row()
                    row.label(text='Register (Vertex Groups)', icon='EDITMODE_HLT')

                    draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/setup_objects/#2-define-facial-parts')

                    def draw_assign_group_options(row, grp_name, grp_name_ui):
                        row.operator('faceit.assign_group', text=grp_name_ui,
                                     icon='GROUP_VERTEX').vertex_group = grp_name
                        row.operator('faceit.clear_faceit_groups', text='', icon='X').group = 'faceit_'+grp_name

                    # Eyes
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Eyeballs (Mandatory)')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'left_eyeball', 'Left Eyeball')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'right_eyeball', 'Right Eyeball')

                    # Other Eyes
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Cornea, Iris, Spots, Highlights')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'left_eyes_other', 'Other Left')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'right_eyes_other', 'Other Right')

                    # Eyelashes
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Eyelashes, Eyeshells, Tearlines')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'eyelashes', 'Eyelashes (Lids)')

                    # Teeth
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Teeth, Gum')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'upper_teeth', 'Upper Teeth')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'lower_teeth', 'Lower Teeth')

                    # Tongue
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Tongue')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'tongue', 'Tongue')

                    # Rigid
                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Rigid, No Deform')

                    row = col_edit.row(align=True)
                    draw_assign_group_options(row, 'rigid', 'Rigid')

                    col_edit.separator(factor=1.0)
                    col_edit.label(text='Clear')
                    row = col_edit.row(align=True)
                    op = row.operator('faceit.clear_faceit_groups', text='Reset All', icon='TRASH')
                    op.group = 'faceit_left_eyeball, faceit_right_eyeball, faceit_left_eyes_other, faceit_right_eyes_other, faceit_upper_teeth, faceit_lower_teeth, faceit_tongue, faceit_eyelashes, faceit_rigid'
                    op.all_objects = True

                    if context.object:
                        if context.object.type != 'MESH':
                            col_edit.enabled = False

            else:
                row = col.row(align=True)
                op = row.operator('faceit.add_facial_part', text='Register Face Object', icon='ADD')
                op.facial_part = 'main'

        # logic
        rig = scene.objects.get('FaceitRig')

        ############ RIGGING ################

        if active_tab == 'CREATE':

            adaption_state = -1

            def eyeballs_registered():
                _objs = [item.get_object() for item in face_objects]
                return (any([obj.vertex_groups.get('faceit_left_eyeball') for obj in _objs])
                        and any([obj.vertex_groups.get('faceit_right_eyeball') for obj in _objs]))

            if scene.faceit_object_name and eyeballs_registered():
                adaption_state = 0
            else:
                col = layout.column()
                row = col.row()
                row.alert = True
                op = row.operator('faceit.go_to_tab', text='Complete Setup First...')
                op.tab = 'SETUP'

            # landmarks setup
            text = 'Generate Landmarks'
            obj = bpy.data.objects.get('facial_landmarks')
            if obj:
                state = obj.get('state')
                if state:
                    if state == 0:
                        text = 'Locate Chin'
                    elif state == 1:
                        text = 'Scale Height'
                    elif state == 2:
                        text = 'Scale Width'
                    elif state == 3:
                        text = 'Project Landmarks'

                    adaption_state += state
            # facial setup modal
            col = layout.column(align=True)

            if adaption_state in range(0, 3):
                row = col.row()
                row.label(text='Landmarks')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/setup_objects/')

                col.prop(scene, 'faceit_asymmetric', text='Asymmetry (Experimental)', icon='EXPERIMENTAL')
                op = col.operator('faceit.facial_landmarks', text=text, icon='TRACKER')

            elif bpy.data.objects.get('facial_landmarks'):
                if not rig:
                    # Return to Landmarks
                    row = col.row()
                    row.label(text='Return')

                    draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/rigging/#back-to-landmarks')

                    col.operator('faceit.reset_facial_landmarks', icon='BACK')
                    if scene.faceit_asymmetric:
                        row = col.row(align=True)
                        row.label(text='Edit')
                        row = col.row(align=True)
                        row.prop(obj.data, 'use_mirror_x', text='', icon='MOD_MIRROR')
                        row.separator()
                        row.operator('faceit.mirror_selected_verts', icon='ARROW_LEFTRIGHT')
                        if context.mode != 'EDIT_MESH':
                            row.enabled = False
                    if adaption_state in range(2, 4):
                        # facial projection
                        col.label(text='Landmarks')
                        col.operator('faceit.facial_project', icon='MOD_SHRINKWRAP')
                    else:
                        # Generate Rig
                        row = col.row()
                        row.label(text='Generate')

                        draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/rigging/')

                        row = col.row()
                        col.operator('faceit.generate_rig', text='Generate Rig and Animation', icon='ARMATURE_DATA')

            # binding
            if rig:
                row = col.row()
                row.label(text='Return')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/rigging/#back-to-landmarks')

                op = col.operator('faceit.reset_to_landmarks', icon='BACK')

                row = col.row()
                row.label(text='Bind')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/rigging/#2-bind-primary')

                box = col.box()
                col_bind = box.column(align=True)
                row = col_bind.row()
                row.prop(scene, 'faceit_bind_options_expanded',  text='Bind Options',
                         icon='TRIA_DOWN' if scene.faceit_bind_options_expanded else 'TRIA_RIGHT',
                         icon_only=True, emboss=False
                         )

                # faceit_bind_settings
                faceit_bind_settings = scene.faceit_bind_settings

                if scene.faceit_bind_options_expanded:
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'smart_weight')
                    if faceit_bind_settings.smart_weight:
                        row.prop(faceit_bind_settings, 'multi_islands_fix')
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'remove_all_vertex_groups')
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'bind_scale_objects')
                    if faceit_bind_settings.bind_scale_objects:
                        row.prop(faceit_bind_settings, 'bind_scale_factor')
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'smooth_bind')
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'clean_weights')
                    if faceit_bind_settings.clean_weights:
                        row.prop(faceit_bind_settings, 'weight_limit')
                    row = col_bind.row()
                    row.prop(faceit_bind_settings, 'auto_bind_secondary', icon='MOD_DATA_TRANSFER')

                row = col.row(align=True)
                op = row.operator('faceit.bind_facial', text='Bind', icon='OUTLINER_OB_ARMATURE')

                row = col.row(align=True)
                op = row.operator('faceit.transfer_groups', icon='MOD_DATA_TRANSFER')
                # col.separator()
                row = col.row()
                row.label(text='Correct Bind')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/rigging/#4-corrective-smooth')

                row = col.row()
                op = row.operator('faceit.smooth_correct', icon='MOD_SMOOTH')

        ############ ADAPTION ################

        if active_tab == 'ADAPT':
            if rig:
                col = layout.column(align=True)
                row = col.row()
                row.label(text='Expressions')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/animation/')

                col.separator()
                # anim list
                col_opt = col.column(align=True)
                if rig.hide_viewport == False:
                    row = col_opt.row(align=True)
                    row.prop(scene, 'faceit_expression_list_options_show_all', icon='MENU_PANEL')
                    if context.mode == 'POSE':
                        row = col_opt.row(align=True)
                        row.prop(scene, 'faceit_use_auto_mirror_x',
                                 text='Auto Mirror X (Pose Option)', icon='MOD_MIRROR')
                        row = col_opt.row(align=True)
                        row.prop(scene.tool_settings, 'use_keyframe_insert_auto', icon='RADIOBUT_ON')
                else:
                    row = col_opt.row(align=True)
                    row.operator('faceit.test_action', icon='ACTION')

                col_opt.separator()

                #layout, data, item, icon, active_data, active_propname
                col.template_list('ANIM_UL_list', '', bpy.context.scene,
                                                  'faceit_expression_list', scene, 'faceit_expression_list_index')
                # set frame
                if rig.hide_viewport == False:
                    row = col.row(align=True)
                    row.operator('faceit.set_timeline', text='Timeline to Pose', icon='TIME')
                    # row = col.row(align=True)
                    # op = row.operator('faceit.mirror_overwrite', text='Mirror Active Expressions', icon='MOD_MIRROR')
                    # op.expression_to_mirror = 'ACTIVE'
                    row = col.row(align=True)
                    op = row.operator('faceit.shape_reset', text='Reset All Expressions', icon='LOOP_BACK')
                    op.expression_to_reset = 'ALL'

            else:
                col = layout.column()
                row = col.row()
                row.alert = True
                op = row.operator('faceit.go_to_tab', text='Generate Rig First...')
                op.tab = 'CREATE'

        ############ BAKING ################

        if active_tab == 'BAKE':
            col = layout.column(align=True)
            row = col.row()
            row.label(text='Bake and Finalize')

            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/workaround/')

            col.separator()

            if context.scene.faceit_shapes_generated:
                row = col.row(align=True)
                row.operator('faceit.reset_to_rig', icon='BACK')

            row = col.row(align=True)
            row.operator('faceit.generate_shapekeys', icon='USER')
            row = col.row(align=True)
            row.prop(scene, 'faceit_generate_action', text='Generate Test Action')

            col.separator(factor=1)
            row = col.row(align=True)
            row.alert = True

            if not scene.faceit_face_objects:
                op = row.operator('faceit.go_to_tab', text='Complete Setup First...')
                op.tab = 'SETUP'

            elif not rig:
                op = row.operator('faceit.go_to_tab', text='Generate Rig First...')
                op.tab = 'CREATE'

            elif rig and not scene.faceit_shapes_generated:
                if not futils.get_armature_modifier(futils.get_main_faceit_object()):
                    op = row.operator('faceit.go_to_tab', text='Bind Rig First...')
                    op.tab = 'CREATE'

            box = layout.box()
            row = box.row()
            draw_panel_dropdown_expander(row, scene, 'faceit_other_utilities_expanded', 'Faceit Utils')

            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/workaround/')

            if scene.faceit_other_utilities_expanded:

                col = box.column()

                if not scene.faceit_face_objects:
                    row = box.row()
                    row.alert = True
                    op = row.operator('faceit.go_to_tab', text='Complete Setup First...')
                    op.tab = 'SETUP'
                    col.enabled = False
                else:
                    col.enabled = True

                row = col.row(align=True)
                row.operator('faceit.test_action', icon='ACTION')

                row = col.row(align=True)

                row.label(text='Duplicate Workaround')

                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/workaround/')

                row = col.row(align=True)
                row.prop(scene, 'faceit_overwrite_shape_keys_on_transfer')
                row = col.row(align=True)
                row.operator('faceit.transfer_shape_keys', icon='MOD_DATA_TRANSFER')

                if check(module_name="transfer_vertex_order")[1]:
                    row = col.row(align=True)
                    row.operator('object.vert_id_transfer_proximity',
                                 text='Transfer Vertex Order', icon='MOD_DATA_TRANSFER')
                else:
                    row = col.row(align=True)
                    draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/workaround/#51-transfer-vertex-order')

                # box_reorder = box.box()
                # col = box_reorder.column(align=True)
                col = col.column(align=True)
                row = col.row(align=True)
                row.label(text='Reorder Shapekey Indices')
                draw_reorder_box(col, scene)

        if active_tab == 'MOCAP':
            col_mocap = layout.column()
            box = col_mocap.box()

            row = box.row()
            draw_panel_dropdown_expander(row, scene, 'faceit_mocap_general_expand_ui', 'Mocap Settings')
            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/')

            if scene.faceit_mocap_general_expand_ui:
                box_reorder = box.box()
                col = box_reorder.column(align=True)
                draw_reorder_box(col, scene)

                box_action = box.box()
                col = box_action.column(align=True)
                row = col.row(align=True)

                draw_panel_dropdown_expander(row, scene, 'faceit_mocap_action_expand', 'Action')
                if scene.faceit_mocap_action_expand:
                    row = col.row(align=True)
                    row.prop(scene, 'faceit_mocap_action', text='')
                    op = row.operator('faceit.populate_action', icon='ACTION_TWEAK')
                    row = col.row(align=True)
                    row.operator('faceit.new_action', icon='ADD')

                box_targets = box.box()
                col = box_targets.column(align=True)
                row = col.row()
                motion_types_setup = scene.faceit_mocap_motion_types
                draw_panel_dropdown_expander(row, motion_types_setup, 'expand', 'Motion Types (Experimental)')
                # row.label(text = 'Targets')
                # Property Group holding Face Cap Settings
                if motion_types_setup.expand:
                    row = col.row(align=True)
                    row.prop(motion_types_setup, 'blendshapes_target', icon='SHAPEKEY_DATA')
                    row.prop(motion_types_setup, 'eye_target_rotation', icon='CON_ROTLIKE')
                    row = col.row(align=True)
                    row.prop(motion_types_setup, 'head_target_location', icon='ORIENTATION_VIEW')
                    row.prop(motion_types_setup, 'head_target_rotation', icon='CON_ROTLIKE')

                    if motion_types_setup.head_target_location or motion_types_setup.head_target_rotation:

                        col.separator()

                        row = col.row(align=True)
                        op = row.operator('faceit.face_cap_empty', text='Create Head Target')
                        op.face_cap_empty = 'HEAD'
                        row = col.row(align=True)
                        row.prop_search(scene, 'faceit_mocap_target_head', bpy.data, 'objects', text='')
                        op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                        op_populate.face_cap_empty = 'HEAD'
                        obj = scene.objects.get(scene.faceit_mocap_target_head)
                        if obj:
                            row = col.row(align=True)
                            row.popover('FACEIT_PT_DeltaTransformHead')

                    if motion_types_setup.eye_target_rotation:

                        col.separator()

                        row = col.row(align=True)
                        op = row.operator('faceit.face_cap_empty', text='Create Eye Targets')
                        op.face_cap_empty = 'EYES'
                        row = col.row(align=True)
                        row.prop_search(scene, 'faceit_mocap_target_eye_l', bpy.data, 'objects', text='')
                        op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                        op_populate.face_cap_empty = 'EYE_L'

                        row.prop_search(scene, 'faceit_mocap_target_eye_r', bpy.data, 'objects', text='')
                        op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                        op_populate.face_cap_empty = 'EYE_R'
                        obj = scene.objects.get(
                            scene.faceit_mocap_target_eye_r) or scene.objects.get(
                            scene.faceit_mocap_target_eye_l)
                        if obj:
                            row = col.row(align=True)
                            row.popover('FACEIT_PT_DeltaTransformEyeLeft')
                            row.popover('FACEIT_PT_DeltaTransformEyeRight')

            box = col_mocap.box()
            col = box.column(align=True)

            face_cap_mocap_settings = scene.faceit_face_cap_mocap_settings

            row = col.row()
            draw_panel_dropdown_expander(row, face_cap_mocap_settings, 'master_expanded', 'Face Cap')
            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/')

            if face_cap_mocap_settings.master_expanded:

                col.separator(factor=2.0)

                box_live = col.box()
                col_live = box_live.column()
                row = col_live.row()

                draw_panel_dropdown_expander(row, face_cap_mocap_settings, 'live_mode_expanded', 'LIVE Mocap')
                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#4-live-capturing-osc')
                if face_cap_mocap_settings.live_mode_expanded:

                    if check(module_name="AddRoutes")[1]:
                        row = col_live.row(align=True)
                        row.operator('faceit.add_routes')
                        row = col_live.row(align=True)
                        row.operator('faceit.clear_routes')
                        if not scene.MOM_Items:
                            row.enabled = False

                        row = col_live.row(align=True)
                        row.prop(scene, 'faceit_record_face_cap', text='Record', icon='REC')
                        if not scene.MOM_Items:
                            row.enabled = False
                    else:
                        row = col_live.row(align=True)
                        draw_web_link(
                            row,
                            'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#live-capturing-osc-stream',
                            text_ui='Install AddRoutes First...', show_always=True)

                col.separator(factor=1.0)

                box_txt = col.box()
                row = box_txt.row()

                draw_panel_dropdown_expander(row, face_cap_mocap_settings, 'file_import_expanded', 'TXT Import')
                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#5-load-recorded-motion-txt')

                if face_cap_mocap_settings.file_import_expanded:

                    row = box_txt.row(align=True)
                    row.prop(face_cap_mocap_settings, 'filename', text='')
                    op = row.operator('faceit.custom_path', text='Load FaceCap TXT', icon='FILE_FOLDER')
                    op.engine = 'FC'

                    col_txt = box_txt.column()

                    row = col_txt.row(align=True)
                    row.prop(face_cap_mocap_settings, 'load_to_new_action', icon='ACTION_TWEAK')
                    if not face_cap_mocap_settings.load_to_new_action:
                        row.prop(scene, 'faceit_mocap_action', text='')

                    row = col_txt.row(align=True)
                    row.operator_context = 'INVOKE_DEFAULT'

                    row.prop(face_cap_mocap_settings, 'frame_start')
                    op = row.operator('faceit.import_mocap', icon='IMPORT')
                    op.engine = 'FC'

                    col_txt.enabled = (face_cap_mocap_settings.filename is not '')

            ######################## UE Live Link Face ##################################
            ue_mocap_settings = scene.faceit_epic_mocap_settings

            box_ue = col_mocap.box()
            row = box_ue.row()
            draw_panel_dropdown_expander(row, ue_mocap_settings, 'master_expanded', 'Live Link Face')
            draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/')

            if ue_mocap_settings.master_expanded:

                box_txt = box_ue.box()
                row = box_txt.row()

                draw_panel_dropdown_expander(row, ue_mocap_settings, 'file_import_expanded', 'CSV Import')
                draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#5-load-recorded-motion-txt')

                if ue_mocap_settings.file_import_expanded:

                    row = box_txt.row(align=True)
                    row.prop(ue_mocap_settings, 'filename', text='')
                    op = row.operator('faceit.custom_path', text='Load UE4 CSV', icon='FILE_FOLDER')
                    op.engine = 'UE'

                    col_txt = box_txt.column()
                    row = col_txt.row(align=True)
                    row.prop(ue_mocap_settings, 'load_to_new_action', icon='ACTION_TWEAK')
                    if not ue_mocap_settings.load_to_new_action:
                        row.prop(scene, 'faceit_mocap_action', text='')

                    row = col_txt.row(align=True)
                    row.operator_context = 'INVOKE_DEFAULT'

                    row.prop(ue_mocap_settings, 'frame_start')
                    op = row.operator('faceit.import_mocap', icon='IMPORT')
                    op.engine = 'UE'

                    col_txt.enabled = (ue_mocap_settings.filename is not '')


class FACEIT_PT_Deltas():
    bl_label = "Deltas"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'


class FACEIT_PT_DeltaTransformHead(FACEIT_PT_Deltas, bpy.types.Panel):
    bl_label = "Delta Transformation Head"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_head)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")


class FACEIT_PT_DeltaTransformEyeLeft(FACEIT_PT_Deltas, bpy.types.Panel):
    bl_label = "Delta Transformation Eye Left"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_eye_l)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")


class FACEIT_PT_DeltaTransformEyeRight(FACEIT_PT_Deltas, bpy.types.Panel):
    bl_label = "Delta Transformation Eye Right"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_eye_r)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")
