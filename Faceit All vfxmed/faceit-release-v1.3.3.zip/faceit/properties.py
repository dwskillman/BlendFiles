import bpy
from . import faceit_utils as futils
from bpy.types import PropertyGroup, Scene, Object
from bpy.props import StringProperty, BoolProperty, PointerProperty, EnumProperty, CollectionProperty, FloatProperty, IntProperty


class Face_Objects(PropertyGroup):
    name: StringProperty(
        name='Object Name',
        description='object name'
    )
    # Problem with object ids, they have to be deleted globally,
    # otherwise they will never be none. Even if deleted from scene..
    obj_pointer: PointerProperty(
        name='Object',
        type=Object
    )
    part: StringProperty(
        name='Facial Part',
        description='The facial part that this object represents'
    )
    warnings: StringProperty(
        name='Warnigns',
        default=''
    )

    def get_object(self):
        return futils.get_object(self.name)


class Mocap_Engine_Properties(PropertyGroup):
    filename: StringProperty(
        name='Filename',
        default='',
    )
    frame_start: IntProperty(
        name='Start at Frame',
        description='Experimental for negative frames',
        default=0,
    )
    master_expanded: BoolProperty(
        name='Expand UI',
        default=False,
    )
    file_import_expanded: BoolProperty(
        name='Expand UI',
        default=False,
    )
    live_mode_expanded: BoolProperty(
        name='Expanded UI',
        default=False,
    )
    mocap_engine: StringProperty(
        name='Mocap Engine',
        description='The software or app to record or stream motion'
    )
    indices_order: StringProperty(
        name='Order of Shape Key Indices',
        description='The order of the Shape Keys used by this engine'
    )
    load_to_new_action: BoolProperty(
        name='Import to new action',
        default=False,
    )


class Anim_Properties(PropertyGroup):
    name: StringProperty()
    side: StringProperty()
    frame: IntProperty()
    index: IntProperty()
    mirror_name: StringProperty()


class Mocap_Motion_Types(PropertyGroup):
    __props = ['blendshapes_target', 'head_target_rotation', 'head_target_location', 'eye_target_rotation']

    name: StringProperty(
        name='The name of the propertyinstance',
        default='Mocap Target Setup'
    )
    blendshapes_target: BoolProperty(
        name='Shape Keys',
        default=True,
    )
    head_target_rotation: BoolProperty(
        name='Head Rotation',
        default=False
    )
    head_target_location: BoolProperty(
        name='Head Location',
        default=False
    )
    eye_target_rotation: BoolProperty(
        name='Eye Rotation',
        default=False
    )
    expand: BoolProperty(default=False)

    def read_settings(self):
        ''' Returns all prop values '''
        return [getattr(self, p) for p in self.__props]


class Bind_Settings(PropertyGroup):
    __props = ['remove_all_vertex_groups', 'bind_scale_objects',
               'bind_scale_factor', 'smart_weight', 'smooth_bind', 'auto_bind_secondary']

    remove_all_vertex_groups: BoolProperty(
        name='Clear Unlocked Vertex Groups',
        description='This will delete all existing vertex groups except for those registered by Faceit and those locked',
        default=True)

    bind_scale_objects: BoolProperty(
        name='Scale Geometry',
        description='Temporarilly scales the geometry for Binding. reduces the chance of errors in binding.',
        default=True
    )

    bind_scale_factor: IntProperty(
        name='',
        description='Factor to scale by. Tweak this if your binding fails',
        default=100
    )

    smart_weight: BoolProperty(
        name='Smart Weights',
        description='Improves weights for most characters, by detecting rigid skull vertices and assigning them to DEF-face group',
        default=True)

    multi_islands_fix: BoolProperty(
        name='Multi Islands (Fix)',
        description='Sometimes this leads to better DEF-face weights when main geo is composed of multiple islands',
        default=False
    )

    auto_bind_secondary: BoolProperty(
        name='Bind Secondary',
        description='Automatically bind the secondary objects after binding is finished.',
        default=True,
    )

    smooth_bind: BoolProperty(
        name='Apply Smoothing',
        description='Applies automatic weight-smoothing after binding.',
        default=True
    )

    clean_weights: BoolProperty(
        name='Clean Weights',
        description='Removes Vertex Weights below the given threshold.',
        default=True
    )

    weight_limit: FloatProperty(
        name='',
        description='Removes Vertex Weights below the given threshold.',
        default=0.001,
        precision=5,
    )

    def read_settings(self):
        ''' Returns all prop values '''
        return [getattr(self, p) for p in self.__props]


def update_shape_index(self, context):
    scene = self

    new_expression = scene.faceit_expression_list[scene.faceit_expression_list_index]
    scene.frame_current = new_expression.frame
    rig = futils.get_object('FaceitRig')
    if rig and scene.faceit_use_auto_mirror_x:
        rig.pose.use_mirror_x = (new_expression.mirror_name == '')


def update_auto_mirror_x(self, context):
    rig = futils.get_object('FaceitRig')
    if rig is not None:
        rig.pose.use_mirror_x = self.faceit_expression_list[self.faceit_expression_list_index].mirror_name == ''


def update_object_index(self, context):
    scene = self
    if scene.faceit_face_index_updated != scene.faceit_face_index:
        scene.faceit_face_index_updated = scene.faceit_face_index

        # face_objects = futils.get_faceit_objects_list()
        face_objects = scene.faceit_face_objects

        index = scene.faceit_face_index
        item = face_objects[index]

        # if context.mode == 'EDIT_MESH':
        if context.object:
            bpy.ops.object.mode_set(mode='OBJECT')

        if item.get_object():
            futils.clear_object_selection()
            futils.set_active_object(item.name)
            scene.faceit_active_object = context.active_object.name
        else:
            scene.faceit_face_objects.remove(index)
        scene.faceit_face_index_updated = -2


def scene_change_listener(scene, depsgraph):
    '''handler to select counter part in face_objects collection prop. Maybe Overkill'''
    # check if we need to iterate through updates at all
    if not depsgraph.id_type_updated('SCENE'):
        return

    for update in depsgraph.updates:
        if isinstance(update.id, Scene):
            #print('Object \"{}\" updated.'.format(update.id.name))
            # the scene
            context = bpy.context
            scene = context.scene
            face_objects = scene.faceit_face_objects  # futils.get_faceit_objects_list()
            if not face_objects:
                return
            selected_objects = context.selected_objects
            if not selected_objects or len(selected_objects) > 1:
                return
            obj = selected_objects[0]
            index = face_objects.find(obj.name)
            if index != -1:
                if scene.faceit_active_object != context.active_object.name:
                    scene.faceit_active_object = context.active_object.name
                    scene.faceit_face_index = index
                    # Reset faceit_face_index_updated to a value out of range
                    scene.faceit_face_index_updated = -2


def tab_changer(self, context):

    active_tab = futils.get_active_tab_from_workflow(self)

    if active_tab == 'SETUP':
        print('enable handler')
        bpy.app.handlers.depsgraph_update_post.clear()
        bpy.app.handlers.depsgraph_update_post.append(scene_change_listener)
    else:
        print('disable handler')
        bpy.app.handlers.depsgraph_update_post.clear()


def update_workflow(self, context):
    tab_changer(self, context)


def update_record_face_cap(self, context):
    shape_key_set = False
    # if self.MOM_items:
    for item in self.MOM_Items:
        if not shape_key_set:
            if item.osc_address == '/W':
                item.record = self.faceit_record_face_cap
                shape_key_set = True
        elif item.osc_address != '/W':
            item.record = self.faceit_record_face_cap


def register():

    Scene.faceit_face_objects = CollectionProperty(
        type=Face_Objects
    )
    Scene.faceit_face_index = IntProperty(
        default=0,
        update=update_object_index
    )
    Scene.faceit_face_index_updated = IntProperty(
        default=1,
    )
    Scene.faceit_active_object = StringProperty(
        default='',
    )

    Scene.faceit_show_warnings = BoolProperty(
        name='Show Warnings',
        default=False,
    )

    Scene.faceit_object_name = StringProperty(
        name='Face object name',
        description='Face object name',
        default='',
    )

    Scene.faceit_asymmetric = BoolProperty(
        name='Symmetry or no symmetry',
        description='Enable this if the Character Geometry is not symmetrical in X Axis. \
Use the manual Mirror tools instead of the Mirror modifier',
        default=False,
    )

    Scene.faceit_matched = IntProperty(
        name='Adaption status',
        default=0
    )

    Scene.faceit_bound = IntProperty(
        name='Bind status',
        default=0
    )

    Scene.faceit_shapes_generated = IntProperty(
        name='Generated Shape Keys',
        default=0
    )

    Scene.faceit_restrict_range = BoolProperty(
        name='restrict',
        description='restrict the Shape Key baking process to the active frame range'
    )

    Scene.faceit_bind_options_expanded = BoolProperty(
        name='Bind Options',
        description='Show Binding Options',
        default=False
    )

    Scene.faceit_generate_action = BoolProperty(
        name="bake action",
        description='wether to generate a Test Action or not',
        default=True
    )

    Scene.faceit_expression_list_index = IntProperty(
        default=0,
        update=update_shape_index
    )

    Scene.faceit_expression_list = CollectionProperty(
        name='animation property collection',
        description='holds all expressions',
        type=Anim_Properties
    )

    Scene.faceit_expression_list_options_show_all = BoolProperty(
        name='Show All Options',
        description='Shows the Mirror and Reset Operators for all Expressions',
        default=False,
    )

    Scene.faceit_use_auto_mirror_x = BoolProperty(
        name='Auto Mirror X',
        default=True,
        description='Automatically enable mirrorX pose option on expression change',
        update=update_auto_mirror_x,
    )

    Scene.faceit_smooth_bone_group = EnumProperty(
        items=(
            ('LID', 'Eyelids', 'Eyelids and brows'),
            ('LIP', 'Lips', 'Upper and Lower Lips'),
            ('JAW', 'Jaw', 'Jaw and Chin')
        )
    )

    Scene.faceit_vertex_size = FloatProperty(
        name='vertex size',
        default=3
    )

    Scene.faceit_bind_settings = PointerProperty(
        name='Bind Settings',
        type=Bind_Settings
    )

    Scene.faceit_weights_restorable = BoolProperty(
        default=False,
    )

    Scene.faceit_active_workflow = EnumProperty(
        name='The Active Faceit Workflow',
        items=(
            ('ALL', 'All', 'Choose this option if you want to have all functionality available.'),
            ('RIG', 'Rig', 'Chosse this option if you only want to create blendshapes. Motion Capture Utils are hidden.'),
            ('MOCAP', 'Mocap', 'Choose this option when your geometry has blendshapes and you only want to do Motion Capture'),
        ),
        default='ALL',
        update=update_workflow,
    )

    Scene.faceit_active_tab = EnumProperty(
        items=(
            ('SETUP', 'Setup', 'Setup Tab'),
            ('CREATE', 'Rig', 'Create Tab'),
            ('ADAPT', 'Animate', 'Adaption Tab'),
            ('BAKE', 'Bake', 'Bake Tab'),
            ('MOCAP', 'Mocap', 'Motion Capture')
        ),
        default='SETUP',
        update=tab_changer,
    )

    Scene.faceit_only_rig_active_tab = EnumProperty(
        items=(
            ('SETUP', 'Setup', 'Setup Tab'),
            ('CREATE', 'Rig', 'Create Tab'),
            ('ADAPT', 'Animate', 'Adaption Tab'),
            ('BAKE', 'Bake', 'Bake Tab'),
        ),
        default='SETUP',
        update=tab_changer,
    )
    Scene.faceit_only_mocap_active_tab = EnumProperty(
        items=(
            ('SETUP', 'Setup', 'Setup Tab'),
            ('MOCAP', 'Mocap', 'Motion Capture')
        ),
        default='SETUP',
        update=tab_changer,
    )

    Scene.faceit_expand_workflow = BoolProperty(
        default=False,
    )

    ############## Utilities ##################

    Scene.faceit_other_utilities_expanded = BoolProperty(
        name='Faceit Utilities',
        default=False
    )

    Scene.faceit_auto_reordering = BoolProperty(
        name='Auto Reorder Indices',
        default=True,
        description='This will reorder the shapekey indices automatically depending on your capturing application'
    )

    Scene.faceit_overwrite_shape_keys_on_transfer = BoolProperty(
        name='Overwrite Existing on Transfer.',
        default=True,
        description='Overwrites the existing Shape Keys on active Mesh'
    )

    ############## Mocap General ##################

    Scene.faceit_mocap_general_expand_ui = BoolProperty(
        default=False
    )

    Scene.faceit_mocap_action = PointerProperty(
        type=bpy.types.Action,
        name='Active Mocap Action',
    )

    Scene.faceit_mocap_action_expand = BoolProperty(
        default=False
    )

    Scene.faceit_target_platform = EnumProperty(
        items=(
            ('ARKIT', 'ARKit Native', 'ARKit Native'),
            ('FACECAP', 'FaceCap', 'bannaflak FaceCap'),
            ('EPIC', 'Epic', 'Epic Games Live Link Face'),
        ),
        default='ARKIT'
    )
    Scene.faceit_mocap_motion_types = PointerProperty(
        name='Face Cap Settings',
        type=Mocap_Motion_Types
    )

    Scene.faceit_mocap_target_head = StringProperty(
        name='Target Head',
        default=''
    )
    Scene.faceit_mocap_target_eye_l = StringProperty(
        name='Target Eye L',
        default=''
    )
    Scene.faceit_mocap_target_eye_r = StringProperty(
        name='Target Eye R',
        default=''
    )

    ############## Face Cap App ##################

    Scene.faceit_face_cap_mocap_settings = PointerProperty(
        type=Mocap_Engine_Properties,
        name='Face Cap Properties',
    )

    Scene.faceit_record_face_cap = BoolProperty(
        name='Record Face Cap Live Mode',
        update=update_record_face_cap,
        default=False,
        description='Record on Play - Setup AddRoutes first'
    )

    ############## Live Link Face ##################

    Scene.faceit_epic_mocap_settings = PointerProperty(
        type=Mocap_Engine_Properties,
        name='Live Link Face Properties',
    )


def unregister():

    bpy.app.handlers.depsgraph_update_post.clear()

    del Scene.faceit_face_objects
    del Scene.faceit_face_index
    del Scene.faceit_face_index_updated
    del Scene.faceit_active_object

    del Scene.faceit_show_warnings

    del Scene.faceit_object_name

    del Scene.faceit_asymmetric

    del Scene.faceit_matched
    del Scene.faceit_bound
    del Scene.faceit_shapes_generated
    del Scene.faceit_restrict_range
    del Scene.faceit_bind_options_expanded
    del Scene.faceit_generate_action

    del Scene.faceit_expression_list_index
    del Scene.faceit_expression_list
    del Scene.faceit_expression_list_options_show_all
    del Scene.faceit_use_auto_mirror_x

    del Scene.faceit_smooth_bone_group
    del Scene.faceit_vertex_size

    del Scene.faceit_bind_settings
    del Scene.faceit_weights_restorable

    del Scene.faceit_active_workflow
    del Scene.faceit_active_tab
    del Scene.faceit_only_rig_active_tab
    del Scene.faceit_only_mocap_active_tab

    del Scene.faceit_expand_workflow

    del Scene.faceit_other_utilities_expanded
    del Scene.faceit_auto_reordering
    del Scene.faceit_overwrite_shape_keys_on_transfer

    del Scene.faceit_mocap_general_expand_ui
    del Scene.faceit_mocap_action
    del Scene.faceit_mocap_action_expand
    del Scene.faceit_target_platform
    del Scene.faceit_mocap_motion_types
    del Scene.faceit_mocap_target_head
    del Scene.faceit_mocap_target_eye_l
    del Scene.faceit_mocap_target_eye_r

    del Scene.faceit_face_cap_mocap_settings
    del Scene.faceit_record_face_cap

    del Scene.faceit_epic_mocap_settings
