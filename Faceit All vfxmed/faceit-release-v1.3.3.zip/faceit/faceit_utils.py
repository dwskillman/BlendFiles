import bpy
import time
from numpy import mean
from math import pi, acos
from mathutils import Vector


def get_active_tab_from_workflow(scene):
    workflow = scene.faceit_active_workflow
    active_tab_dict = {
        'RIG': scene.faceit_only_rig_active_tab,
        'MOCAP': scene.faceit_only_mocap_active_tab,
        'ALL': scene.faceit_active_tab,
    }
    return active_tab_dict[workflow]


def get_object(name):
    '''
    returns an object or none
    @name: the name of the obj
    '''
    if isinstance(name, str):
        obj = bpy.context.scene.objects.get(name)
        if obj:
            return obj
        else:
            pass
    return None


def remove_item_from_collection_prop(collection, item):
    '''Removes an @item from a given @collection'''
    collection.remove(collection.find(item.name))


def get_faceit_objects_list(clear_invalid_objects=True):
    '''Returns the registered faceit objects in a list.
    Removes items that can't be found in the scene from the propertycollection
    @clear_invalid_objects: when True, this will remove unfound items from the collection
    '''

    faceit_objects_property_collection = bpy.context.scene.faceit_face_objects

    faceit_objects = []

    for obj_item in faceit_objects_property_collection:
        # try to find by obj_pointer
        obj = get_object(obj_item.name)
        if obj is not None:
            faceit_objects.append(obj)
            continue
        elif clear_invalid_objects:
            print('removing item {} from faceit objects, because it does not exist in scene.'.format(obj_item.name))
            remove_item_from_collection_prop(faceit_objects_property_collection, obj_item)

    return faceit_objects


def get_main_faceit_object():
    '''Returns the main object (head or face)'''
    scene = bpy.context.scene
    return get_object(scene.faceit_object_name)
    # faceit_objects_property_collection = scene.faceit_face_objects
    # for obj_item in faceit_objects_property_collection:
    # 	if obj_item.part == 'main':
    # 		return get_object(obj_item.name)


def set_active_object(object_name):
    '''
    select the object
    @object_name: String
    '''
    obj = bpy.data.objects.get(object_name)
    if obj:
        bpy.data.objects[object_name].select_set(state=True)
        bpy.context.view_layer.objects.active = obj
    else:
        print('WARNING! Object {} does not exist'.format(obj.name))
        return{'CANCELLED'}


def clear_selection():
    bpy.ops.mesh.select_all(action='DESELECT')


def clear_object_selection():
    bpy.ops.object.select_all(action='DESELECT')


def set_hide_obj(obj, hide):
    '''
    un/hides the object
    @obj : the object
    @hide (bool): True = hide
    '''
    # hide the objectBase in renderlayer
    obj.hide_set(hide)
    # hide the object itself
    obj.hide_viewport = hide


def set_hidden_state_object(object_to_hide, hide_viewport, hide_render):
    '''
    object_to_hide : object to hide
    hide_viewport : hide the object itself
    hide_render : hide the objectBase in renderlayer
    '''
    object_to_hide.hide_viewport = hide_viewport
    object_to_hide.hide_set(hide_render)


def set_hidden_states(objects_hidden_states={}, overwrite=False, objects=[], hide_value=False):
    '''
    Set the state of hidden objects
    @objects_hidden_states : dictionary from get_hidden_states
    @overwrite : overwrite all values
    @objects : objects to hide/unhide
    @hide_value : value if overwrite
    '''
    if overwrite and objects:
        for obj in objects:
            if not obj:
                continue
            set_hidden_state_object(obj, hide_value, hide_value)
    for obj, states in objects_hidden_states.items():
        obj = get_object(obj)
        if not obj:
            continue
        hide_viewport = states[0]
        hide_render = states[1]
        set_hidden_state_object(obj, hide_viewport, hide_render)


def get_hidden_states(objects_to_hide):
    '''returns hidden state of objects in dictioray'''
    list(objects_to_hide)
    objects_hidden = {}
    for obj in objects_to_hide:
        objects_hidden[obj.name] = [obj.hide_viewport, obj.hide_get()]
    return objects_hidden


def get_armature_modifier(obj):
    if obj is None:
        return
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE':
            return mod


def get_modifiers_of_type(obj, type):
    mods = []
    for mod in obj.modifiers:
        if mod.type == type:
            mods.append(mod)
    return mods


def has_shape_keys(obj):
    '''Returns True when the object data holds Shape Keys'''
    if hasattr(obj.data, 'shape_keys'):
        return hasattr(obj.data.shape_keys, 'key_blocks')
    else:
        return False


def reorder_armature_in_modifier_stack(objects=[]):

    if not isinstance(objects, (tuple, list)):
        objects = [objects]

    for obj in objects:

        arm_mod = get_armature_modifier(obj)
        compare_mods = list(filter(None, [*get_modifiers_of_type(obj, 'SUBSURF'),
                                          *get_modifiers_of_type(obj, 'CORRECTIVE_SMOOTH'),
                                          *get_modifiers_of_type(obj, 'WEIGHTED_NORMAL'),
                                          ]))
        if arm_mod and compare_mods:
            while obj.modifiers.find(arm_mod.name) > min([obj.modifiers.find(mod.name) for mod in compare_mods]):
                bpy.ops.object.modifier_move_up({'object': obj}, modifier=arm_mod.name)


def duplicate_obj(collection, obj):
    '''
    Duplicate an object withouth using modifiers
    @scene : needed to link new obj
    @obj : object
    Returns : the duplicate
    '''
    new_obj = obj.copy()
    new_obj.data = obj.data.copy()
    collection.objects.link(new_obj)
    return new_obj


def select_vertices(obj, vs=[]):
    '''
    select vertices in a mesh (OBJECT mode required)
    @obj: the object that holds mesh data
    @vs : vert subset to select
    '''
    verts = vs or obj.data.vertices
    for v in verts:
        v.select = True


def unselect_flush_vert_selection(obj, vs=[]):
    '''
    Unselect vertices in a mesh (OBJECT mode required)
    @obj: the object that holds mesh data
    @vs : vert subset to unselect
    '''
    mesh = obj.data
    verts = mesh.vertices
    faces = mesh.polygons  # not faces!
    edges = mesh.edges
    # vertices can be selected
    # to deselect vertices you need to deselect faces(polygons) and edges at first
    for f in faces:
        f.select = False
    for e in edges:
        e.select = False
    try:
        verts = vs if vs else verts
        for v in verts:
            v.select = False
    except:
        print('deselection failed')


def get_mouse_select():
    active_kc = bpy.context.preferences.keymap.active_keyconfig
    active_pref = bpy.context.window_manager.keyconfigs[active_kc].preferences
    return getattr(active_pref, 'select_mouse', 'LEFT')


def delete_edit_bone(editbone):
    bpy.context.active_object.data.edit_bones.remove(editbone)


def reset_stretch(bone):
    ''' reset stretch constraints '''
    # it is important to frame_set before resetting!
    bpy.context.scene.frame_set(1)
    for c in bone.constraints:
        if c.name == 'Stretch To':
            c.rest_length = 0


def get_median_pos(locations):
    '''
    returns the center of all points in locations
    @locations : list of points (Vector3) in one space
    '''
    return Vector(mean(locations, axis=0).tolist())


def remove_all_animation_for_frame(action, frame):
    ''' Removes all keyframes from @action at @frame '''
    time_start = time.time()
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            if key.co[0] == frame:
                curve.keyframe_points.remove(key)
    print('took {}'.format(round(time.time() - time_start, 2)))


def create_overwrite_animation(rig_obj):
    '''
    adds an action to the rig objects stack
    @rig_obj : the rig, that holds the shape animations.
    '''
    shape_strip = rig_obj.animation_data.nla_tracks.get('ShapeTrack').strips[0]
    nla_tracks = rig_obj.animation_data.nla_tracks
    ow_action = bpy.data.actions.get('faceit_shape_action').copy()

    ow_action.name = 'overwrite_shape_action'
    new_track = nla_tracks.new()
    new_track.name = 'OverwriteTrack'
    frame_start = shape_strip.frame_start
    ow_strip = new_track.strips.new('overwrite_shape_clip', frame_start, ow_action)
    ow_strip.frame_end = shape_strip.frame_end
    rig_obj.animation_data.action = ow_action
    rig_obj['overwrite_init'] = 1

    return ow_action


def exit_nla_tweak_mode(context):
    '''exit the nla tweak mode (important for nla editor actions)'''
    current_type = bpy.context.area.type
    bpy.context.area.type = 'NLA_EDITOR'
    bpy.ops.nla.tweakmode_exit()
    bpy.context.area.type = current_type


def get_active_expression():
    ''' returns the active expression from expression_list property'''
    return bpy.context.scene.faceit_expression_list[bpy.context.scene.faceit_expression_list_index]


def mirror_key_frame(context, frame_from, frame_to):
    '''
    mirror keyframe to the opposite side
    @frame_from : frame mirror from
    @frame_to : frame mirror to
    '''
    current_type = bpy.context.area.type
    bpy.context.area.type = 'DOPESHEET_EDITOR'
    bpy.ops.action.select_all(action='DESELECT')
    # select channels to effect
    bpy.ops.anim.channels_select_all(action='SELECT')
    context.scene.frame_current = frame_from
    bpy.ops.action.select_column(mode='CFRA')
    bpy.ops.action.copy()
    context.scene.frame_current = frame_to
    bpy.ops.action.paste(flipped=True)
    bpy.context.area.type = current_type


def reset_key_frame(context, frame):
    ''' reset keyframe on overwrite action to original value in shape action (undo edits) '''
    current_type = bpy.context.area.type
    bpy.context.area.type = 'DOPESHEET_EDITOR'
    bpy.context.space_data.ui_mode = 'ACTION'
    context.object.animation_data.action = bpy.data.actions.get('faceit_shape_action')
    bpy.context.space_data.dopesheet.show_only_selected = False
    bpy.ops.action.select_all(action='DESELECT')
    context.scene.frame_current = frame
    # maybe faster in fcurve.evaluate(frame)
    bpy.ops.action.select_column(mode='CFRA')
    bpy.ops.action.copy()
    context.object.animation_data.action = bpy.data.actions.get('overwrite_shape_action')
    bpy.ops.action.paste()
    bpy.context.area.type = current_type


def assign_vertex_grp(obj, vertices, grp_name, overwrite=False):
    '''
    assigns the vertices to a vertex group
    @obj : the object that holds the mesh
    @vertices : list of vertex indices
    @grp_name : the name of the new vertex group
    @overwrite : wether the vertices should be added to grp or replace existing grp.
    '''
    vert_group = obj.vertex_groups.get(grp_name)

    # create new group if it does not exist
    if not vert_group:
        vert_group = obj.vertex_groups.new(name=grp_name)

    if overwrite:
        # remove all verts in object from the group
        remove_verts_from_grp(obj, vert_group)

    # set active group
    obj.vertex_groups.active_index = vert_group.index
    # assign 1 to all non facial vertices
    vert_group.add(vertices, 1, 'REPLACE')


def remove_verts_from_grp(obj, vertex_group, vs=[]):
    '''
    remove vertices from a vertex group
    @obj : the object that holds the mesh
    @grp_name : the vertex group
    @vs : subset of vertex indices
    '''
    # remove vert subset
    if vs:
        vertex_group.remove(vs)
    # remove all verts
    else:
        vertex_group.remove(range(len(obj.data.vertices)))


def remove_deform_vertex_grps(obj, remove_all=False):
    '''
    Removes all DEF (deform) vertex groups from an object
    @obj : the object
    @remove_all : Remove all Vertex Group except faceit groups
    '''
    if len(obj.vertex_groups) <= 0:
        return
    for grp in obj.vertex_groups:
        if not 'faceit' in grp.name:
            if not grp.lock_weight:
                if 'DEF' in grp.name or remove_all:
                    obj.vertex_groups.remove(grp)


def remove_faceit_vertex_grps(obj):
    '''
    Remove all user defined faceit vertex groups on obj
    @obj : the object
    '''
    if len(obj.vertex_groups) <= 0:
        return
    removed = []
    for grp in obj.vertex_groups:
        if 'faceit' in grp.name:
            removed.append(grp.name)
            obj.vertex_groups.remove(grp)
    return removed


def remove_all_weight(obj, vs=[]):
    '''
    remove all weights from DEF groups for passed vertices
    @obj : object to that holds groups and mesh
    @vs : the vertices that should be unweighted
    '''
    # either vertex subset to unweight or all
    verts = vs if vs else obj.data.vertices
    for v in verts:
        for i in range(len(v.groups)):
            if 'DEF' in obj.vertex_groups[v.groups[i].group].name:
                v.groups[i].weight = 0


def get_faceit_vertex_grps(obj, groups_filter=[]):
    '''
    check for user defined faceit groups on obj
    returns : list of all faceit groups on obj
    @obj : the object
    @groups_filter : list of vertex groups to check for, keywords alloud
    '''
    if len(obj.vertex_groups) <= 0:
        return
    faceit_groups = []

    for grp in obj.vertex_groups:
        if groups_filter:
            if any([(i in grp.name) for i in groups_filter]):
                faceit_groups.append(grp.name)
        else:
            if 'faceit' in grp.name:
                faceit_groups.append(grp.name)

    return faceit_groups


rigid_deform_groups = [
    'DEF_eye.L',
    'DEF_eye.R',
    'DEF-teeth.T',
    'DEF-teeth.B',
    'DEF-tongue',
    'DEF-tongue.001',
    'DEF-tongue.002',
]


def get_faceit_rigid_deform_grps(obj, groups_filter=[]):
    '''
    check for vertex groups on obj
    returns : list of all vgroups that are in rigid_bind_groups on obj
    @obj : the object
    @groups_filter : list of vertex groups to check for, keywords alloud
    '''
    if len(obj.vertex_groups) <= 0:
        return
    rigid_deform_groups_found = []

    for grp in obj.vertex_groups:
        if grp.name in rigid_deform_groups:
            rigid_deform_groups_found.append(grp.name)

    return rigid_deform_groups_found


def get_verts_in_vgroup(obj, grp_name):
    '''
    get all vertices in a vertex group
    Returns : list of vertices in group, else None
    @obj : object holds group and verts
    @grp_name : the name of the vertex group to get verts from
    '''
    vg_idx = obj.vertex_groups.find(grp_name)
    if vg_idx == -1:
        # print('[faceit_utils/get_verts_in_grp()] vgroup does not exist')
        return
    # get all vertices in faceit group
    return [v for v in obj.data.vertices if vg_idx in [vg.group for vg in v.groups]]


def has_verts_without_grps(obj):
    return any([not v.groups for v in obj.data.vertices])


def is_inside_dot(target_pt_global, mesh_obj, tolerance=0.05):
    '''
    checks if a point is inside a surface, by the dot product method
    @target_pt_global : the point to check
    @mesh_obj : the mesh as surface
    @tolerance : a threshold as inside tolerance
    '''
    # Convert the point from global space to mesh local space
    target_pt_local = mesh_obj.matrix_world.inverted() @ target_pt_global

    # Find the nearest point on the mesh and the nearest face normal
    _, pt_closest, face_normal, _ = mesh_obj.closest_point_on_mesh(target_pt_local)

    # Get the target-closest pt vector
    target_closest_pt_vec = (pt_closest - target_pt_local).normalized()

    # Compute the dot product = |a||b|*cos(angle)
    dot_prod = target_closest_pt_vec.dot(face_normal)

    # Get the angle between the normal and the target-closest-pt vector (from the dot prod)
    angle = acos(min(max(dot_prod, -1), 1)) * 180 / pi

    # Allow for some rounding error
    inside = angle < 90-tolerance

    return inside


class SelectionIslands:
    '''
    Traces the graph of edges and verts to find the islands
    @verts : bmesh vertices
    @selection_islands : the islands of adjacent selected vertices
    @non_selected_islands : the islands of adjacent non selected vertices
    '''

    verts = []
    selected_islands = []
    non_selected_islands = []
    # wether selected or non selected islands should be searched

    def __init__(self, bmesh_verts):
        self.verts = bmesh_verts
        self.sort_selection_start(self.verts)

    def make_vert_paths(self, verts, search_selected):
        # Init a set for each vertex
        result = {v: set() for v in verts}
        # Loop over vertices to store connected other vertices
        for v in verts:
            for e in v.link_edges:
                other = e.other_vert(v)
                if other.select == search_selected:
                    result[v].add(other)
        return result

    def make_island(self, starting_vert, paths):
        # Initialize the island
        island = [starting_vert]
        # Initialize the current vertices to explore
        current = [starting_vert]

        follow = True
        while follow:
            # Get connected vertices that are still in the paths
            eligible = set([v for v in current if v in paths])
            if len(eligible) == 0:
                follow = False  # Stops if no more
            else:
                # Get the corresponding links
                next = [paths[i] for i in eligible]
                # Remove the previous from the paths
                for key in eligible:
                    island.append(key)
                    paths.pop(key)
                # Get the new links as new inputs
                current = set([vert for sub in next for vert in sub])

        return island

    def make_islands(self, bm_verts, search_selected):
        paths = self.make_vert_paths(bm_verts, search_selected)
        result = []
        found = True
        while found:
            try:
                # Get one input as long there is one
                vert = next(iter(paths.keys()))
                # Deplete the paths dictionary following this starting vertex
                result.append(self.make_island(vert, paths))
            except:
                found = False
        return result

    def sort_selection_start(self, bm_verts):
        non_selected_verts = []
        selected_verts = []
        for v in bm_verts:
            if v.select:
                selected_verts.append(v)
            else:
                non_selected_verts.append(v)
        self.selected_islands = self.make_islands(selected_verts, search_selected=True)
        self.non_selected_islands = self.make_islands(non_selected_verts, search_selected=False)

    def get_selected_islands(self):
        return self.selected_islands

    def get_non_selected_islands(self):
        return self.non_selected_islands

    def get_island_count(self):
        return len(self.non_selected_islands + self.selected_islands)
