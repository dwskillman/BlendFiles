
import bpy
from operator import attrgetter
from . import faceit_data as fdata
from mathutils import Vector
from . import faceit_utils as futils


class FACEIT_OT_GenerateRig(bpy.types.Operator):
    '''Generates the Rig that holds the shapekey animation'''
    bl_idname = 'faceit.generate_rig'
    bl_label = 'Generate Rig'
    bl_options = {'UNDO', 'INTERNAL'}

    use_existing_weights: bpy.props.BoolProperty(
        name='Bind with Existing Weights',
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return futils.get_main_faceit_object()

    def invoke(self, context, event):
        # if self.all_objects:
        if context.scene.faceit_weights_restorable:
            wm = context.window_manager
            return wm.invoke_props_dialog(self)
        else:
            return self.execute(context)

    def execute(self, context):
        scene = context.scene
        if context.object:
            bpy.ops.object.mode_set(mode='OBJECT')
        # landmarks done - reset vertex size
        bpy.context.preferences.themes[0].view_3d.vertex_size = scene.faceit_vertex_size

        faceit_collection = bpy.data.collections.get('Faceit_Collection')
        if not faceit_collection:
            faceit_collection = bpy.data.collections.new(name='Faceit_Collection')
            scene.collection.children.link(faceit_collection)

        # load the objects data in the rig file
        with bpy.data.libraries.load(fdata.faceit_data.get_rig_file()) as (data_from, data_to):
            data_to.objects = data_from.objects

        # add only the armature
        for obj in data_to.objects:
            if obj.type == 'ARMATURE' and obj.name == 'FaceitRig':
                faceit_collection.objects.link(obj)

        futils.clear_object_selection()
        futils.set_active_object('FaceitRig')

        bpy.ops.faceit.init_anim_props()
        bpy.ops.faceit.match()
        rig = futils.get_object('FaceitRig')

        ow_action = futils.create_overwrite_animation(rig)

        rig.animation_data.action = ow_action
        scene.frame_start, scene.frame_end = ow_action.frame_range[:]

        if self.use_existing_weights:
            bpy.ops.faceit.pair_armature()
            self.report({'INFO'}, 'Restored Existing Weights. You can regenerate weights by using the Bind operator')

        return {'FINISHED'}


class FACEIT_OT_Match(bpy.types.Operator):
    '''matches the bones with reference mesh positions'''
    bl_idname = 'faceit.match'
    bl_label = 'match anim rig'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        if context.active_object == futils.get_object('FaceitRig'):
            return True

    def execute(self, context):
        scene = context.scene

        if scene.is_nla_tweakmode:
            futils.exit_nla_tweak_mode(context)

        rig = futils.get_object('FaceitRig')

        rig.data.use_mirror_x = False if scene.faceit_asymmetric else True

        face_objects = futils.get_faceit_objects_list()
        # the landmarks mesh holds the bone locations
        landmarks = futils.get_object('facial_landmarks')

        edit_bones = rig.data.edit_bones
        # adapt scale
        bpy.ops.object.mode_set(mode='EDIT')
        # bones that fall too far off the rigs dimensions, hinder the scale adaption
        bones = ['eyes', 'eye.L', 'eye.R', 'DEF-face', 'MCH-eyes_parent']
        bone_translation = {}
        # temporarilly move bones to center of rig (only Y Axis/ dimensions[1] matters)
        for bone in bones:
            bone = edit_bones.get(bone)
            # store bone position
            bone_translation[bone.name] = (bone.head[1], bone.tail[1])
            # move to rig center
            bone.head[1] = bone.tail[1] = 0

        bpy.ops.object.mode_set(mode='OBJECT')
        rig.location = landmarks.location
        rig.dimensions = landmarks.dimensions
        bpy.ops.object.mode_set(mode='EDIT')

        # restore the original positions
        for bone, pos in bone_translation.items():
            if bone in ['eye.L', 'eye.R']:
                pos = bone_translation['eyes']
            bone = edit_bones.get(bone)
            bone.head[1], bone.tail[1] = pos

        # the dictionary containing
        vert_dict = fdata.faceit_data.get_bone_dict()
        # the mesh world matrix
        w_mat = rig.matrix_world
        # the bone space local matrix
        l_mat = rig.matrix_world.inverted()

        # save Settings
        layer_state = rig.data.layers[:]
        # enable all armature layers; needed for armature operators to work properly
        for i in range(len(rig.data.layers)):
            rig.data.layers[i] = True

        def get_median_position_from_vert_grp(vgroup):
            '''
            returns a median point of the vertices assossiated with:
            @vgroup = the user defined vertex groups, for facial parts.
            '''
            # get the first object in face_objects that has vgroup assigned
            try:
                obj = next(iter([obj for obj in face_objects if obj.vertex_groups.get(vgroup)]))
            except StopIteration:
                return None

            vs = futils.get_verts_in_vgroup(obj, vgroup)

            if not vs:
                self.report(
                    {'WARNING'},
                    'You registered the empty group {}! The group is removed from registration'.format(vgroup))
                grp = obj.vertex_groups.get(vgroup)
                if grp:
                    obj.vertex_groups.remove(grp)
                return None

            mw = obj.matrix_world
            # get the global coordinates of teeth vertices
            global_v_co = [mw @ v.co for v in vs]

            if 'tongue' in vgroup:
                position = min(global_v_co, key=attrgetter('y'))
                position.x = 0
            # teeth or eyes
            else:
                # get bounds (highest and lowest vertex)
                bounds = [(max(global_v_co, key=attrgetter('z'))), (min(global_v_co, key=attrgetter('z')))]
                position = futils.get_median_pos(bounds)
                # for teeth only - set y as well
                if 'teeth' in vgroup:
                    bounds = [(max(global_v_co, key=attrgetter('y'))), (min(global_v_co, key=attrgetter('y')))]
                    position.y = futils.get_median_pos(bounds).y
                    position.x = 0

            return position

        for i, bone_dict in vert_dict.items():

            # all vertices in the reference mesh
            if i < 100:
                # the world coordinates of the specified vertex
                target_point = landmarks.matrix_world @ landmarks.data.vertices[i].co

            ############# Special Cases ##############

            # eyes extra positions
            elif i == 101:
                target_point = get_median_position_from_vert_grp('faceit_left_eyeball')
            elif i == 111:
                target_point = get_median_position_from_vert_grp('faceit_right_eyeball')

            # jaw extra positions
            elif i == 102:
                target_point = w_mat @ edit_bones['jaw.L'].head
                target_point.x = 0

            # nose extra positions
            elif i == 103:
                b_tip = edit_bones['nose.002'].head
                b_top = edit_bones['nose'].head
                vec = b_tip - b_top
                target_point = w_mat @ (b_top + vec * 0.7)

            elif i == 104:
                b_1 = edit_bones['nose.004'].head
                b_2 = edit_bones['lip.T'].head
                target_point = w_mat @ futils.get_median_pos([b_1, b_2])
            elif i == 105:
                b_1 = edit_bones['nose.002'].head
                b_2 = edit_bones['nose.004'].head
                target_point = w_mat @ futils.get_median_pos([b_1, b_2])

            # teeth extra positions
            elif i == 106:
                target_point = get_median_position_from_vert_grp('faceit_upper_teeth')
                if not target_point:
                    self.report({'WARNING'}, 'could not find upper teeth, define teeth group first!')
                    for b in vert_dict[106]['all']:
                        bone = edit_bones[b]
                        edit_bones.remove(bone)
                    continue
            elif i == 107:
                target_point = get_median_position_from_vert_grp('faceit_lower_teeth')
                if not target_point:
                    self.report({'WARNING'}, 'could not find lower teeth, define teeth group first!')
                    for b in vert_dict[107]['all']:
                        bone = edit_bones[b]
                        edit_bones.remove(bone)
                    continue
            elif i == 108:
                continue
            elif i == 109:
                # Get position between jaw rear
                jaw_L = edit_bones.get('jaw.L').head
                jaw_R = edit_bones.get('jaw.R').head
                target_point = w_mat @ futils.get_median_pos([jaw_L, jaw_R])

            ############# Matching ##############

            # all - translates head and tail by vector to target_point
            for b in bone_dict['all']:
                bone = edit_bones[b]
                l_point = l_mat @ target_point
                vec = l_point - bone.head
                bone.translate(vec)

            # head - translates head to target_point
            for b in bone_dict['head']:
                bone = edit_bones[b]
                bone.head = l_mat @ target_point

            # tail - translates tail to target_point
            for b in bone_dict['tail']:
                bone = edit_bones[b]
                bone.tail = l_mat @ target_point

        # apply same offset to all tongue bones
        tip_tongue = get_median_position_from_vert_grp('faceit_tongue')
        if tip_tongue:
            vec = l_mat @ tip_tongue - edit_bones['tongue'].head
            for b in vert_dict[108]['all']:
                bone = edit_bones[b]
                bone.translate(vec)
        else:
            self.report({'WARNING'}, 'could not find tongue, define teeth group first!')
            for b in vert_dict[108]['all']:
                bone = edit_bones[b]
                edit_bones.remove(bone)

        # translate the extra eye bone to the proper location

        # eye targets:
        eyes = edit_bones['eyes']
        # eyes_length = eyes.length
        eyes_length = Vector((0, 0, eyes.length))

        eye_master_L = edit_bones['master_eye.L']
        eye_master_R = edit_bones['master_eye.R']

        vec = eye_master_L.tail - edit_bones['MCH-eye.L.001'].head
        edit_bones['MCH-eye.L.001'].translate(vec)
        vec = eye_master_R.tail - edit_bones['MCH-eye.R.001'].head
        edit_bones['MCH-eye.R.001'].translate(vec)

        eye_target_L = edit_bones['eye.L']
        eye_target_R = edit_bones['eye.R']

        eyes.head[2] = eye_master_L.head[2]
        eyes.tail = eyes.head + eyes_length
        eye_target_L.head[0] = eye_master_L.head[0]
        eye_target_L.head[2] = eye_master_L.head[2]
        eye_target_L.tail = eye_target_L.head + eyes_length

        # eyes.head[2] = eye_master_R.head[2]
        # eyes.tail = eyes.head + eyes_length
        eye_target_R.head[0] = eye_master_R.head[0]
        eye_target_R.head[2] = eye_master_R.head[2]
        eye_target_R.tail = eye_target_R.head + eyes_length

        # orient all jaw bones for jaw_master.tail (chin)
        jaw_master = edit_bones['jaw_master']
        jaw_master.tail = edit_bones['chin'].head
        for bone in vert_dict[102]['all']:
            if bone != jaw_master.name:
                edit_bones[bone].align_orientation(jaw_master)

        bpy.ops.object.mode_set(mode='OBJECT')
        # restore the layer visibillity to its original state
        rig.data.layers = layer_state[:]

        # apply scale and respectively adapt animation scale
        scale = rig.scale.copy()
        a = bpy.data.actions.get('faceit_shape_action')

        rig.animation_data.action = a
        if scale != Vector((1, 1, 1)):
            # Apply the Transform
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            if scale != rig.scale.copy():
                action = rig.animation_data.action
                for fcurve in action.fcurves:
                    # get the location curves
                    if fcurve.data_path.split('].')[-1] == 'location':
                        # fcurves array index represents location[x,y,z]
                        i = fcurve.array_index
                        # scale the animation
                        for key in fcurve.keyframe_points:
                            key.co[1] *= scale[i]

        # set scene property for program logic
        scene.faceit_matched = 1
        rig['matched'] = 1

        landmarks.hide_viewport = True
        bpy.ops.faceit.proc_anim('INVOKE_DEFAULT', shape='all')

        # reset stretch constraints
        for bone in rig.pose.bones:
            futils.reset_stretch(bone)

        return {'FINISHED'}
