import io
import bpy
import time
import bmesh
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata
from contextlib import redirect_stdout


class FACEIT_OT_BindFacial(bpy.types.Operator):
    '''Bind main objects (Face, Eyes, Teeth, Tongue)'''
    bl_idname = 'faceit.bind_facial'
    bl_label = 'Bind'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        rig = futils.get_object('FaceitRig')
        if rig and context.scene.faceit_face_objects:
            if rig.hide_viewport == False and context.mode == 'OBJECT':
                return True

    def execute(self, context):
        scene = context.scene

        # simplify for performances reasons
        simplify_value = scene.render.use_simplify
        simplify_subd = scene.render.simplify_subdivision
        scene.render.use_simplify = True
        scene.render.simplify_subdivision = 0

        faceit_bind_settings = scene.faceit_bind_settings

        # the main face object
        face_obj = futils.get_main_faceit_object()
        # all face objects
        face_objects = futils.get_faceit_objects_list()

        rig = futils.get_object('FaceitRig')

        lm_obj = futils.get_object('facial_landmarks')

        topo_mirror_face_obj = face_obj.data.use_mirror_topology
        face_obj.data.use_mirror_topology = False

        if not face_obj:
            self.report({'ERROR'}, 'Main face object not found! Complete Setup')
            return{'FINISHED'}
        if not face_objects:
            self.report({'ERROR'}, 'Facial object list not found! Complete Setup!')
            return{'FINISHED'}
        if not lm_obj:
            self.report({'ERROR'}, 'Faceit landmarks not found!')
            return{'FINISHED'}
        if not rig:
            self.report({'ERROR'}, 'Faceit rig not found!')
            return{'FINISHED'}

        for obj in face_objects:
            obj.data.use_mirror_x = False if scene.faceit_asymmetric else True
            mod = futils.get_armature_modifier(obj)
            if mod:
                if mod.object:
                    if not mod.object.name == 'FaceitRig':
                        self.report({'WARNING'}, 'It seems your character geometry was bound to another armature. \
Faceit removed the armature modifier but you should consider to save the original Object and work on a Duplicate. \
Check out the Documentation for more information')

        # settings
        rig.data.pose_position = 'REST'

        objects_to_unhide = [*face_objects, rig, lm_obj]
        objects_hidden_states = futils.get_hidden_states(objects_to_unhide)
        futils.set_hidden_states(overwrite=True, objects=objects_to_unhide, hide_value=False)

        pivot_setting = scene.tool_settings.transform_pivot_point

        auto_key = scene.tool_settings.use_keyframe_insert_auto
        scene.tool_settings.use_keyframe_insert_auto = False

        if faceit_bind_settings.bind_scale_objects:
            def _scale_bind_objects(factor, objects, reverse=False):
                # set transform pivot to 3d cursor in case scaling has to be altered
                scale_factor = (factor,)*3 if not reverse else (1/factor,)*3
                scene.cursor.location = face_obj.location
                scene.tool_settings.transform_pivot_point = 'CURSOR'
                futils.clear_object_selection()
                # select all facial objects
                for obj in objects:
                    futils.set_active_object(obj.name)
                    obj.lock_scale[:] = (False,)*3
                bpy.ops.transform.resize(value=scale_factor)
                # bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

            scale_factor = faceit_bind_settings.bind_scale_factor
            _scale_bind_objects(factor=scale_factor, objects=[rig, *face_objects, lm_obj])

        # unbind the facial rig first - removes old armature modifiers
        bpy.ops.faceit.unbind_facial()

        bind_success = self._bind_facial_rig(context, face_obj, rig, lm_obj, face_objects, faceit_bind_settings)
        print(bind_success)

        # global logic
        scene.faceit_bound = 1
        rig['bound'] = 1

        if faceit_bind_settings.bind_scale_objects:
            # restore original scale
            _scale_bind_objects(factor=scale_factor, objects=[rig, *face_objects, lm_obj], reverse=True)

        bpy.context.scene.render.use_simplify = simplify_value
        bpy.context.scene.render.simplify_subdivision = simplify_subd  # restore settings

        rig.data.pose_position = 'POSE'
        futils.set_hidden_states(objects_hidden_states=objects_hidden_states)
        scene.tool_settings.transform_pivot_point = pivot_setting
        scene.tool_settings.use_keyframe_insert_auto = auto_key
        face_obj.data.use_mirror_topology = topo_mirror_face_obj

        futils.clear_object_selection()
        futils.set_active_object('FaceitRig')

        if bind_success and faceit_bind_settings.auto_bind_secondary:
            bpy.ops.faceit.transfer_groups()
        return {'FINISHED'}

    def _create_facial_hull(self, context, lm_obj):
        '''Duplicates Landmarks mesh and creates a convex hull object from it. Encompasses the face.'''

        # duplicate facial setup - create facial hull as weight envelope
        futils.clear_object_selection()
        futils.set_active_object(lm_obj.name)
        bpy.ops.object.duplicate_move()
        face_hull = context.object

        # apply the mirror mod on hull
        for mod in face_hull.modifiers:
            if mod.name == 'Mirror':
                bpy.ops.object.modifier_apply(modifier=mod.name)

        # make convex hull from the mesh
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.convex_hull()
        # scale up slightly to include whole deform area
        context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
        bpy.ops.transform.resize(value=(2, 1.1, 1.2))

        bpy.ops.object.mode_set(mode='OBJECT')

        return face_hull

    def _remove_weights_from_non_facial_geometry(self, context, face_obj, face_hull, faceit_vertex_groups):
        '''Removes all weights outside of the facial area on the main face object.
        @face_obj: the main facial object
        @face_hull: the convex hull that encompasses the face
        @faceit_vertex_group: Leave the faceit_vertex_groups (teeth, tongue, eyes, rigid) untouched
        '''

        bm = bmesh.new()
        bm.from_mesh(face_obj.data)

        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # deselect all verts:
        for f in bm.faces:
            f.select = False
        bm.select_flush(False)

        # get all vertex indices in faceit defined groups. These should not be compared to selection island
        # (faceit vertices will be overwritten by secondary binding process later on)
        vs_secondary = []

        for vgroup in faceit_vertex_groups:
            if vgroup == 'faceit_eyelashes':
                continue
            vg_idx = face_obj.vertex_groups.find(vgroup)
            if vg_idx == -1:
                # vgroup does not exist
                continue
            vs_secondary.extend([v.index for v in face_obj.data.vertices if vg_idx in [vg.group for vg in v.groups]])

        # get bmesh verts
        verts_to_check = [v for v in bm.verts if v.index not in vs_secondary]

        # select all verts that are inside the facial hull object and not in secondary groups
        # false positives included due to rounding errors
        for v in verts_to_check:
            pt = face_obj.matrix_world @ v.co
            if futils.is_inside_dot(pt, face_hull):
                v.select = True

        ############## Selection errors #################

        # SelectionIslands finds and stores selected and non-selected islands
        _selection_islands = futils.SelectionIslands(verts_to_check)

        _non_selected_islands = _selection_islands.get_non_selected_islands()
        _selected_islands = _selection_islands.get_selected_islands()

        def _keep_only_biggest_island(islands, select_value):
            '''keep only the biggest island, all smaller should be added to/ removed from selection/non-selection
            @islands (list) : list of list of vertices
            @select_value (Bool) : add to selection or remove from selection
            '''
            if len(islands) > 1:
                biggest = max(islands, key=lambda x: len(x))
                for i in islands:
                    if len(i) < len(biggest):
                        for v in i:
                            v.select_set(select_value)

        # keep only the biggest island, the rest should be removed from selection
        _keep_only_biggest_island(_selected_islands, select_value=False)
        bm.select_flush(False)

        if not context.scene.faceit_bind_settings.multi_islands_fix:
            _keep_only_biggest_island(_non_selected_islands, select_value=True)
            bm.select_flush(True)

        bm.to_mesh(face_obj.data)
        bm.free()
        # sometimes single verts get ignore by the selectionislands class, remove by shrink grow selection once
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_less()
        bpy.ops.mesh.select_more()
        bpy.ops.object.mode_set(mode='OBJECT')

        ############## Remove Weights out of hull #################

        # update the non-facial verts based on active selection
        v_face_inv = [v.index for v in face_obj.data.vertices if not v.select and v.index not in vs_secondary]

        # assign 1 to all non facial vertices
        futils.assign_vertex_grp(face_obj, v_face_inv, 'DEF-face', overwrite=True)

        futils.select_vertices(face_obj)

    def _bind_facial_rig(self, context, face_obj, rig, lm_obj, face_objects, faceit_bind_settings):

        bind_problem = False

        # list of user defined facial areas (teeth, tongue, eyes vertex groups) [names(String)]
        faceit_vertex_groups = fdata.get_list_faceit_groups()

        futils.clear_object_selection()
        futils.set_active_object(face_obj.name)

        # Make sure the mesh is visible.
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal()
        bpy.ops.object.mode_set(mode='OBJECT')

        # disable bones deform property for all bones that should not be autoweighted:
        for bone in fdata.get_no_auto_weight():
            bone = rig.data.bones.get(bone)
            if bone:
                bone.use_deform = False

        futils.clear_object_selection()
        face_obj.select_set(state=True)
        futils.set_active_object(rig.name)

        # add armature mod
        warning = 'Warning: Bone Heat Weighting: failed to find solution for one or more bones'
        output = ''

        stdout = io.StringIO()

        with redirect_stdout(stdout):
            original_parent = face_obj.parent
            bpy.ops.object.parent_set(type='ARMATURE_AUTO', keep_transform=True)
            # restore the parent object or set it to None.
            face_obj.parent = original_parent if original_parent != rig else None

        stdout.seek(0)
        output = stdout.read()
        del stdout
        if warning in output:
            self.report({'WARNING'}, warning + ' for object {}. Check the Docs for work-arounds'.format(face_obj.name))
            bind_problem = True

        # rename modifier
        mod = face_obj.modifiers[-1]

        if mod.type == 'ARMATURE':
            mod.object = rig
            mod.name = 'Faceit_Armature'
        else:
            self.report({'WARNING'}, 'No Armature Mod found. Mesh can\'t be bound.')

        # re-enable deform properties:
        for bone in fdata.get_no_auto_weight():
            bone = rig.data.bones.get(bone)
            if bone:
                bone.use_deform = True

        ###### Smart weights ######
        if faceit_bind_settings.smart_weight:

            # Create the facial hull object encompassing the facial geometry.
            face_hull = self._create_facial_hull(context, lm_obj)

            futils.clear_object_selection()
            futils.set_active_object(face_obj.name)

            self._remove_weights_from_non_facial_geometry(context, face_obj, face_hull, faceit_vertex_groups)

            # remove the hull helper object
            bpy.data.objects.remove(face_hull)

        futils.clear_object_selection()
        rig.select_set(state=True)
        futils.set_active_object(face_obj.name)

        # Make Def-face the active vertex group before normalizing
        face_group = face_obj.vertex_groups['DEF-face']
        face_grp_idx = face_group.index
        if face_grp_idx != -1:
            face_obj.vertex_groups.active_index = face_grp_idx

        ###### Smoothing weights ######
        if faceit_bind_settings.smooth_bind:

            use_mask = face_obj.data.use_paint_mask_vertex
            face_obj.data.use_paint_mask_vertex = False

            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')

            # smooth the weights on the face group - for selected verts only

            # face_grp_idx = face_obj.vertex_groups.find('DEF-face')
            if face_grp_idx != -1:
                bpy.ops.object.vertex_group_smooth(group_select_mode='ACTIVE',
                                                   factor=0.5,
                                                   repeat=10,
                                                   expand=0.1,
                                                   )
            # face_group.lock_weight = True
            bpy.ops.object.vertex_group_smooth(group_select_mode='BONE_DEFORM',
                                               factor=0.5,
                                               repeat=1,
                                               expand=0,
                                               )

            face_obj.data.use_paint_mask_vertex = use_mask

            # smooth the weights on the jaw
            # bpy.ops.mesh.select_all(action='SELECT')
            # for grp in face_obj.vertex_groups:
            #     if 'jaw' in grp.name:
            #         face_obj.vertex_groups.active_index = grp.index
            #         bpy.ops.object.vertex_group_smooth(group_select_mode='ACTIVE',
            #                                            factor=.5,
            #                                            repeat=5,
            #                                            )
            #     elif any(name in grp.name for name in ['lid', 'brow.B']):
            #         face_obj.vertex_groups.active_index = grp.index
            #         bpy.ops.object.vertex_group_smooth(group_select_mode='ACTIVE',
            #                                            factor=0.5,
            #                                            repeat=2,
            #                                            expand=0.05
            #                                            )

        # lock and normalize - so the facial influences get restricted
        bpy.ops.object.vertex_group_normalize_all(lock_active=True)
        bpy.ops.object.vertex_group_clean(group_select_mode='ALL', limit=faceit_bind_settings.weight_limit)
        bpy.ops.object.vertex_group_normalize()

        bpy.ops.object.mode_set(mode='OBJECT')

        ############# Skin secondary objects ################

        def bind_secondary(obj, faceit_vertex_group, new_grp=''):
            '''
            bind user defined areas to respective bones with constant weight of 1 on all vertices
            @obj - the object holding the vertex group defined by user
            @faceit_vertex_group - the user defined groups holding all vertices that should be assigned to new group
            i.e. faceit_teeth
            @new_grp - the name of the newly assigned vertex group
            '''
            # get all vertices in the faceit group
            vs = futils.get_verts_in_vgroup(obj, faceit_vertex_group)
            if not vs:
                return
            futils.remove_all_weight(obj, vs)
            # assign new group weight or...
            if new_grp != 'rigid':
                # indices needed for group assignment
                vs = [v.index for v in vs]
                futils.assign_vertex_grp(obj, vs, new_grp)

        # areas dictionary holds the names of faceit groups keyed by facial part
        areas = fdata.get_areas()
        eye_grps = areas['eye_grps']
        teeth_grps = areas['teeth_grps']
        tongue_grps = areas['tongue_grps']
        rigid_grps = areas['rigid_grps']

        for vgroup in faceit_vertex_groups:

            # all objects that hold the spec group
            objects = [obj for obj in face_objects if futils.get_faceit_vertex_grps(obj, [vgroup])]

            for obj in objects:

                futils.clear_object_selection()
                futils.set_active_object(obj.name)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.object.mode_set(mode='OBJECT')
                # add armature mod if it does not exist
                if not futils.get_armature_modifier(obj):
                    new_mod = obj.modifiers.new(name='Faceit_Armature', type='ARMATURE')
                    new_mod.object = rig

                if vgroup in eye_grps:
                    new_grp = 'DEF_eye.L' if 'left' in vgroup else 'DEF_eye.R'
                if vgroup in teeth_grps:
                    new_grp = 'DEF-teeth.T' if 'upper_teeth' in vgroup else 'DEF-teeth.B'
                if vgroup in rigid_grps:
                    new_grp = 'rigid'

                bind_secondary(obj, vgroup, new_grp)

                if vgroup in tongue_grps:

                    # auto weight only tongue bones
                    futils.clear_object_selection()
                    # select rig
                    futils.set_active_object(rig.name)
                    bpy.ops.object.mode_set(mode='POSE')
                    # enable deform bones layer
                    bpy.context.object.data.layers[29] = True
                    tongue_bones = [
                        'DEF-tongue',
                        'DEF-tongue.001',
                        'DEF-tongue.002'
                    ]
                    bpy.ops.pose.select_all(action='DESELECT')
                    # select bones
                    for bone in tongue_bones:
                        pbone = rig.pose.bones.get(bone)
                        if bone:
                            pbone.bone.select = True
                        else:
                            self.report({'WARNING'}, 'Tongue bones do not exist. Regenerate the rig.')
                            continue

                    # select tongue object
                    bpy.ops.object.mode_set(mode='OBJECT')
                    futils.set_active_object(obj.name)

                    # lock all existing groups
                    bpy.ops.object.vertex_group_lock(action='LOCK')

                    # get all verts in tongue group
                    vs = futils.get_verts_in_vgroup(obj, vgroup)

                    if not vs:
                        continue

                    # remove all weights of other bones that got weighted in autoweighting process
                    futils.remove_all_weight(obj, vs)

                    # select all verts in tongue grp
                    futils.unselect_flush_vert_selection(obj)
                    futils.select_vertices(obj, vs=vs)

                    # go weightpaint
                    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                    obj.data.use_paint_mask_vertex = True
                    bpy.ops.paint.weight_from_bones(type='AUTOMATIC')

                    # smooth tongue deform
                    bpy.ops.object.vertex_group_smooth(group_select_mode='BONE_DEFORM', factor=.5, repeat=2, expand=1.5)

                    # reset settings
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.vertex_group_lock(action='UNLOCK')
                    rig.data.layers[29] = False

        # armature modifiers needs to be in front of other mods
        futils.reorder_armature_in_modifier_stack(face_objects)

        if not bind_problem:
            self.report({'INFO'}, 'Binding completed!')
            return True
        else:
            return False


class FACEIT_OT_PairArmature(bpy.types.Operator):
    '''Pair the FaceitRig to the facial objects without generating weights'''
    bl_idname = 'faceit.pair_armature'
    bl_label = 'Pair Armature'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        face_objects = futils.get_faceit_objects_list()
        faceit_rig = futils.get_object(name='FaceitRig')
        if not faceit_rig:
            return{'CANCELLED'}

        for obj in face_objects:

            mod = futils.get_armature_modifier(obj)
            if not mod:
                mod = obj.modifiers.new(name='Faceit_Armature', type='ARMATURE')

            mod.object = faceit_rig

        futils.reorder_armature_in_modifier_stack(face_objects)
        context.scene.faceit_weights_restorable = False

        return{'FINISHED'}


class FACEIT_OT_UnbindFacial(bpy.types.Operator):
    '''Unbind the FaceitRig from the facial objects'''
    bl_idname = 'faceit.unbind_facial'
    bl_label = 'Unbind'
    bl_options = {'UNDO', 'INTERNAL'}

    remove_deform_groups: bpy.props.BoolProperty(
        name='Remove Binding Groups',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        scene = context.scene
        faceit_bind_settings = scene.faceit_bind_settings

        face_objects = futils.get_faceit_objects_list()

        for obj in face_objects:

            a_mod = futils.get_armature_modifier(obj)
            if a_mod:
                obj.modifiers.remove(a_mod)
                # remove all deform vert groups
            if self.remove_deform_groups:
                futils.remove_deform_vertex_grps(obj, remove_all=faceit_bind_settings.remove_all_vertex_groups)
                c_mod = obj.modifiers.get('Corrective_Smooth')
                if c_mod:
                    obj.modifiers.remove(c_mod)

            scene.faceit_bound = 0
        return{'FINISHED'}


class FACEIT_OT_ResetToLandmarks(bpy.types.Operator):
    '''Go back to editing the landmarks'''
    bl_idname = 'faceit.reset_to_landmarks'
    bl_label = 'Back to Landmarks'
    bl_options = {'UNDO', 'INTERNAL'}

    keep_weights: bpy.props.BoolProperty(
        name='Keep Binding Weights',
        description='Keep all Binding Vertex Groups to Restore with the Rig',
        default=False,
    )

    @classmethod
    def poll(cls, context):
        if futils.get_object('FaceitRig') and context.mode == 'OBJECT' and not context.scene.faceit_shapes_generated:
            return True

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene

        bpy.ops.faceit.unbind_facial(remove_deform_groups=not self.keep_weights)
        scene.faceit_weights_restorable = self.keep_weights
        # remove rig
        rig = futils.get_object('FaceitRig')
        bpy.data.objects.remove(rig)
        # reset props
        scene.faceit_bound = 0

        # turn on landmarks visibility
        lm = bpy.data.objects.get('facial_landmarks')
        if lm:
            lm.hide_viewport = False
        else:
            self.report({'WARNING'}, 'Landmarks mesh does not exist anymore.')

        if bpy.app.version >= (2, 83, 0):
            bpy.ops.outliner.orphans_purge()
        return{'FINISHED'}


class FACEIT_OT_CorrectiveSmooth(bpy.types.Operator):
    '''Add corrective smooth modifier to the active object'''

    bl_idname = 'faceit.smooth_correct'
    bl_label = 'Smooth Correct Modifier'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is not None:
            if context.mode == 'OBJECT' and obj.type == 'MESH':
                if not obj.modifiers.get('CorrectiveSmooth'):
                    return True

    def execute(self, context):
        obj = context.object
        mod = obj.modifiers.new(name='CorrectiveSmooth', type='CORRECTIVE_SMOOTH')
        mod.smooth_type = 'LENGTH_WEIGHTED'
        mod.iterations = 4
        mod.use_pin_boundary = True
        # subdiv modifiers need to be last

        sub_mod = obj.modifiers.get('Subdivision')
        if sub_mod:
            while obj.modifiers.find(mod.name) > obj.modifiers.find(sub_mod.name):
                bpy.ops.object.modifier_move_up(modifier=mod.name)
        return{'FINISHED'}


class FACEIT_OT_DataTransfer(bpy.types.Operator):
    '''Data transfer binding weights to secondary objects'''

    bl_idname = 'faceit.transfer_groups'
    bl_label = 'Bind Secondary'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT' and context.scene.faceit_face_objects:
            if futils.get_armature_modifier(futils.get_main_faceit_object()):
                return True

    def execute(self, context):

        scene = context.scene

        faceit_bind_settings = scene.faceit_bind_settings

        face_obj = futils.get_main_faceit_object()

        rig = futils.get_object('FaceitRig')
        # get all faceit objects, filter Nones
        face_objects = futils.get_faceit_objects_list()
        # save the hidden states
        objects_hidden_states = futils.get_hidden_states(face_objects)
        # unhide all
        futils.set_hidden_states(overwrite=True, objects=face_objects, hide_value=False)
        # rig settings
        rig.data.pose_position = 'REST'

        # filter secondary face objects, that hold vertices without vgroups assigned.
        transfer_objects = []

        object_lock_status = {}

        for obj in face_objects:

            # skip main object
            if obj.name == scene.faceit_object_name:
                continue

            arm_mod = futils.get_armature_modifier(obj)
            faceit_vertex_groups = futils.get_faceit_vertex_grps(obj)

            # get objects that were not bound and are registered in faceit objects
            if not arm_mod:
                arm_mod = obj.modifiers.new(name='Faceit_Armature', type='ARMATURE')
                arm_mod.object = rig
                transfer_objects.append(obj)
                self.report({'INFO'}, 'Binding object {}.'.format(obj.name))

            # get objects that were bound and may have unbound vertices that need to be auto wheighted
            if 'faceit_eyelashes' in obj.vertex_groups.keys():
                transfer_objects.append(obj)
                self.report({'INFO'}, 'Binding parts of object {}.'.format(obj.name))

        for obj in transfer_objects:

            eyelashes = bool('faceit_eyelashes' in obj.vertex_groups.keys())

            futils.clear_object_selection()
            futils.set_active_object(obj.name)

            # create, setup data transfer modifier
            data_mod = obj.modifiers.new(name='DataTransfer', type='DATA_TRANSFER')
            data_mod.object = face_obj
            data_mod.use_vert_data = True
            data_mod.data_types_verts = {'VGROUP_WEIGHTS'}

            bpy.ops.object.datalayout_transfer(modifier=data_mod.name)

            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier=data_mod.name)
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier=data_mod.name)

            # go weightpaint
            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')

            # settings
            mask = obj.data.use_paint_mask_vertex
            obj.data.use_paint_mask_vertex = False

            # remove all non lid deform groups
            if eyelashes:
                for vgroup in obj.vertex_groups:
                    if 'DEF' in vgroup.name:
                        if not 'lid' in vgroup.name:
                            obj.vertex_groups.remove(vgroup)
            # remove all faceit groups that were transferred from the main object. These will messup re-binding.
            for vgroup in obj.vertex_groups:
                if 'faceit' in vgroup.name and not 'eyelashes' in vgroup.name:  # or vgroup.name == 'DEF-face':
                    obj.vertex_groups.remove(vgroup)

            # smooth deform
            if faceit_bind_settings.smooth_bind:
                bpy.ops.object.vertex_group_clean(group_select_mode='ALL', limit=0.05)
                bpy.ops.object.vertex_group_smooth(group_select_mode='ALL', factor=.5, repeat=3)

            # normalize removes all wheights from the verts that are locked
            bpy.ops.object.vertex_group_clean(group_select_mode='ALL', limit=faceit_bind_settings.weight_limit)
            bpy.ops.object.vertex_group_normalize_all()

            # reset settings
            bpy.context.object.data.use_paint_mask_vertex = mask
            # any vertex groups? Unlock'em
            bpy.ops.object.mode_set(mode='OBJECT')

        # restore the hidden states to all objects
        futils.set_hidden_states(objects_hidden_states=objects_hidden_states)

        # settings
        rig.data.pose_position = 'POSE'

        return{'FINISHED'}
