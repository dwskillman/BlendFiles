import bpy
import numpy as np
from addon_utils import check
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata


class FACEIT_OT_GenerateShapekeys(bpy.types.Operator):
    '''Bakes the poses of the FaceitRig to Shape Keys on the registered objects'''
    bl_idname = 'faceit.generate_shapekeys'
    bl_label = 'Bake ARKit Shape Keys'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            obj = futils.get_main_faceit_object()
            if obj is not None:
                if futils.get_armature_modifier(obj):
                    if futils.get_object('FaceitRig'):
                        return True

    def execute(self, context):

        scene = context.scene

        # if subsurface modifier, weighted Normal -> turn off temporarily
        allowed_modifiers = ['ARMATURE', 'CORRECTIVE_SMOOTH']

        bake_objects = list()
        obj_mod_show = dict()

        faceit_objects = futils.get_faceit_objects_list()

        for obj in faceit_objects:
            obj.shape_key_clear()

            if futils.get_armature_modifier(obj):
                bake_objects.append(obj)

                # disable subsurface modifiers
                for mod in obj.modifiers:
                    if mod.type == 'MIRROR':
                        self.report(
                            {'WARNING'},
                            'The object {} contains a mirror mirror modifier. Results may not be as expected.'.format(
                                obj.name))
                    if mod.type not in allowed_modifiers and mod.show_viewport == True:
                        mod.show_viewport = False
                        try:
                            obj_mod_show[obj.name].append(mod.name)
                        except KeyError:
                            obj_mod_show[obj.name] = [mod.name]
                # create basis sk
                basis_shape = obj.shape_key_add(name='Basis')
                basis_shape.interpolation = 'KEY_LINEAR'

        # hidden states of all objects
        objects_hidden_states = futils.get_hidden_states(bake_objects)
        futils.set_hidden_states(overwrite=True, objects=bake_objects, hide_value=False)

        save_frame = scene.frame_current

        # redo the procedural animation in case something changed
        bpy.ops.faceit.proc_anim('INVOKE_DEFAULT', shape='mouth_close')

        rig_obj = futils.get_object('FaceitRig')

        expression_list = scene.faceit_expression_list

        depth = context.evaluated_depsgraph_get()

        for expression in expression_list:

            scene.frame_set(expression.frame)

            for obj in bake_objects:

                verts = obj.evaluated_get(depth).data.vertices
                vert_count = len(verts)

                sk_data = np.zeros(vert_count*3, dtype=np.float32)
                verts.foreach_get('co', sk_data.ravel())

                shape = obj.shape_key_add(name=expression.name)

                shape.data.foreach_set('co', sk_data.ravel())

                shape.interpolation = 'KEY_LINEAR'

        for obj in bake_objects:
            for m in obj.modifiers:
                if m.type == 'ARMATURE':
                    obj.modifiers.remove(m)
                    continue
                if m.type == 'CORRECTIVE_SMOOTH':
                    m.show_viewport = False
                    m.show_render = False

            # enable modifiers that have been enabled before.
            for obj in obj_mod_show.keys():
                for mod in obj_mod_show[obj]:
                    futils.get_object(obj).modifiers[mod].show_viewport = True

        # cleanup scene
        lm_obj = bpy.data.objects.get('facial_landmarks')
        if lm_obj:
            lm_obj.hide_viewport = True
        rig_obj.hide_viewport = True

        # restore
        futils.set_hidden_states(objects_hidden_states=objects_hidden_states)
        scene.frame_current = save_frame
        futils.clear_object_selection()
        scene.faceit_shapes_generated = True

        if scene.faceit_generate_action:
            bpy.ops.faceit.test_action()

        return{'FINISHED'}


class FACEIT_OT_ResetToRig(bpy.types.Operator):
    '''Reset Faceit to Rigging and Posing functionality, removes the baked Shape Keys'''
    bl_idname = 'faceit.reset_to_rig'
    bl_label = 'Back to Rigging'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(self, context):
        if context.mode == 'OBJECT':
            return futils.get_main_faceit_object()

    def execute(self, context):

        scene = context.scene
        if check(module_name="AddRoutes")[1]:
            scene.MOM_Items.clear()
        rig = bpy.data.objects.get('FaceitRig')
        # restore scene
        if rig:
            rig.hide_viewport = False

        faceit_objects = futils.get_faceit_objects_list()

        for obj in faceit_objects:
            # remove all shapekeys on object
            if not obj.data.shape_keys:
                continue
            obj.shape_key_clear()

            if futils.get_armature_modifier(obj):
                continue
            else:
                new_mod = obj.modifiers.new(name='Faceit_Armature', type='ARMATURE')
                new_mod.object = rig
            # if any([mod.type == 'CORRECTIVE_SMOOTH' for mod in obj.modifiers]):
            #     obj
            corrective_mod = obj.modifiers.get('CorrectiveSmooth')
            if corrective_mod:
                corrective_mod.show_viewport = True
                corrective_mod.show_render = True

        futils.reorder_armature_in_modifier_stack(faceit_objects)

        scene.faceit_shapes_generated = False

        bpy.ops.outliner.orphans_purge()

        futils.clear_object_selection()
        futils.set_active_object(rig.name)

        bpy.ops.faceit.init_anim_props()
        return {'FINISHED'}
