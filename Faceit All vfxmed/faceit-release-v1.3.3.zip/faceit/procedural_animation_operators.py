import bpy
from mathutils import Vector
from . import faceit_utils as futils


def _remove_constraint_influence_for_frame(arm_obj, bone, frame):
    '''
    Removes the influence for the specified frame for the specified bone
    @arm_obj : the object holding the armature data
    @bone : a pose bone (in arm_obj.data)
    @frame : the frame that should be free of constraint influence
    '''
    for c in bone.constraints:
        original_value = c.influence
        arm_obj.keyframe_insert(
            data_path='pose.bones["{}"].constraints["{}"].influence'.format(bone.name, c.name),
            frame=frame - 10)
        c.influence = 0
        arm_obj.keyframe_insert(
            data_path='pose.bones["{}"].constraints["{}"].influence'.format(bone.name, c.name),
            frame=frame - 9)
        arm_obj.keyframe_insert(
            data_path='pose.bones["{}"].constraints["{}"].influence'.format(bone.name, c.name),
            frame=frame)
        c.influence = original_value
        arm_obj.keyframe_insert(
            data_path='pose.bones["{}"].constraints["{}"].influence'.format(bone.name, c.name),
            frame=frame + 1)


class FACEIT_OT_proc_animations(bpy.types.Operator):
    # tooltip
    '''
    Procedurally create the animations that need to be adapted to character style
    - mouth close is the delta animation between jaw open and lips closed
    - eye blink is the blinking animation that needs to adapted to eye shape
    '''

    bl_idname = 'faceit.proc_anim'
    bl_label = 'Procedurally Animate'
    bl_options = {'UNDO', 'INTERNAL'}

    shape: bpy.props.StringProperty(name='Shape')

    @classmethod
    def poll(cls, context):
        if futils.get_object('FaceitRig'):
            return True

    def execute(self, context):

        scene = context.scene
        rig = futils.get_object('FaceitRig')
        action = rig.animation_data.action
        # scene settings
        if scene.is_nla_tweakmode:
            futils.exit_nla_tweak_mode(context)

        expression_list = scene.faceit_expression_list

        def _get_bone_delta(bone1, bone2):
            '''returns object space vector between two pose bones'''
            pos1 = bone1.matrix.translation
            pos2 = bone2.matrix.translation
            vec = pos1 - pos2
            return vec

        if self.shape in ['mouth_close', 'all']:

            jaw_open_shape = expression_list['jawOpen']
            mouth_close_shape = expression_list['mouthClose']

            # for each pose bone: get the delta vector that should be applied to the mouth close shape
            lip_pose_bones = {
                'top': ['lip.T.L.001', 'lip.T', 'lip.T.R.001'],
                'bot': ['lip.B.L.001', 'lip.B', 'lip.B.R.001'],
                'corner': ['lips.L', 'lips.R'],
            }
            all_bones = [rig.pose.bones.get(bone) for bone in lip_pose_bones.values() for bone in bone]

            def _get_bone_by_name(bone_list, bone_name):
                return next(bone for bone in bone_list if bone.name == bone_name)

            lip_top = _get_bone_by_name(all_bones, 'lip.T')
            lip_bot = _get_bone_by_name(all_bones, 'lip.B')
            lips_corner = _get_bone_by_name(all_bones, 'lips.L')

            # the delta vector botton lip to top lip on neutral face
            scene.frame_set(0)
            delta_bot_top_idle = Vector()
            delta_bot_top_idle.z = (lip_top.matrix.translation[2] - lip_bot.matrix.translation[2]) / 4

            scene.frame_set(jaw_open_shape.frame)
            # reset/remove animations in case the user recreates them
            futils.remove_all_animation_for_frame(action, mouth_close_shape.frame)
            # get the delta in height between top lip and corner, apply as offset for evenly spaced lip
            delta_corner_top_jaw_open = Vector()
            delta_corner_top_jaw_open.z = (lip_top.matrix.translation[2] - lips_corner.matrix.translation[2]) / 2.5

            mouth_close_dict = {}  # dictionary contains bones and respective translation vectors to close jaw to the top lip

            for bone in all_bones:

                bone_translation_delta = Vector()
                # scale delta, hardcoded for now
                bone_scale_delta = Vector((1, ) * 3)

                if bone.name in lip_pose_bones['top']:
                    # position delta
                    if '.001' in bone.name:
                        bone_translation_delta = delta_corner_top_jaw_open / 2
                    else:
                        bone_translation_delta = delta_corner_top_jaw_open

                    bone_scale_delta *= 1.2

                if bone.name in lip_pose_bones['bot']:
                    top_bone = _get_bone_by_name(all_bones, bone.name.replace('.B', '.T'))
                    bone_translation_delta = _get_bone_delta(bone, top_bone)
                    bone_translation_delta.z = bone_translation_delta.z * 0.7
                    bone_scale_delta *= 1.3
                    if '.001' in bone.name:
                        bone_scale_delta *= 1.4

                if bone.name in lip_pose_bones['corner']:
                    bone_scale_delta *= 1.3
                    # bone_translation_delta = delta_bot_top_idle * -1
                mouth_close_dict[bone] = {'scale': bone_scale_delta,
                                          'translation': bone_translation_delta,
                                          }

            # apply the vector to bones
            scene.frame_set(mouth_close_shape.frame)

            for bone, delta_values in mouth_close_dict.items():
                # get the position delta for each bone and add a slight offset
                bone_translation_delta = delta_values['translation'] + delta_bot_top_idle

                # disable constraints before moving the bones
                _remove_constraint_influence_for_frame(rig, bone, mouth_close_shape.frame)

                # the local bone position
                bone_pos = bone.matrix.translation.copy()

                # translation by vec
                final_pos = bone_pos - bone_translation_delta  # * .7

                # update the pose bone matrix
                bone.matrix.translation = final_pos

                # apply scale delta
                bone.scale = delta_values['scale']

                bone.keyframe_insert(data_path='location', frame=mouth_close_shape.frame)
                bone.keyframe_insert(data_path='scale', frame=mouth_close_shape.frame)

            delta_top_bot_mouth_close = Vector()
            delta_top_bot_mouth_close.z = (lip_top.matrix.translation[2] - lips_corner.matrix.translation[2]) / 2

            for bone in lip_pose_bones['corner']:
                bone = _get_bone_by_name(all_bones, bone)

                bone_pos = bone.matrix.translation.copy()

                # translation by vec
                final_pos = bone_pos + delta_top_bot_mouth_close  # * .7

                bone.matrix.translation = final_pos
                bone.keyframe_insert(data_path='location', frame=mouth_close_shape.frame)

        if self.shape in ['eye_blink', 'all']:

            ######################## EYE BLINK ANIM #########################

            top_lid_pose_bones = ['lid.T.L.003', 'lid.T.L.002', 'lid.T.L.001', ]
            bot_lid_pose_bones = ['lid.B.L.001', 'lid.B.L.002', 'lid.B.L.003', ]
            brow_bot_pose_bones = ['brow.B.L.004', 'brow.B.L.003', 'brow.B.L.002', 'brow.B.L.001', 'brow.B.L']
            sides = ['L', 'R']  # Left Right
            vec = None

            for side in sides:
                if side == 'L':
                    shape_name = 'eyeBlinkLeft'
                else:
                    shape_name = 'eyeBlinkRight'
                    top_lid_pose_bones = [bone.replace('.L', '.R') for bone in top_lid_pose_bones]
                    bot_lid_pose_bones = [bone.replace('.L', '.R') for bone in bot_lid_pose_bones]
                    brow_bot_pose_bones = [bone.replace('.L', '.R') for bone in brow_bot_pose_bones]

                eye_blink = scene.faceit_expression_list[shape_name]
                frame = eye_blink.frame
                #futils.remove_all_animation_for_frame(action, frame)
                scene.frame_set(frame)

                for bones in list(zip(top_lid_pose_bones, bot_lid_pose_bones)):
                    top_lid_bone = rig.pose.bones.get(bones[0])
                    bot_lid_bone = rig.pose.bones.get(bones[1])  # the target

                    # remove any constraint influence so the bones can be directly animated
                    _remove_constraint_influence_for_frame(rig, top_lid_bone, frame)

                    vec = _get_bone_delta(top_lid_bone, bot_lid_bone)

                    new_pos = top_lid_bone.matrix.translation - vec * 0.9

                    top_lid_bone.matrix.translation = new_pos  # b_bone.matrix.translation
                    top_lid_bone.keyframe_insert(data_path='location', frame=frame)

                for bone in brow_bot_pose_bones:
                    bone = rig.pose.bones.get(bone)

                    # remove any constraint influence so the bones can be directly animated
                    _remove_constraint_influence_for_frame(rig, bone, frame)

                    # offset1 = direction of bottom lid
                    bot_lid_bone = rig.pose.bones.get('lid.B.{}.002'.format(side))
                    vec = _get_bone_delta(bone, bot_lid_bone)

                    # toplid direction offset
                    top_lid_bone = rig.pose.bones.get('lid.T.{}.002'.format(side))
                    offset = _get_bone_delta(bone, top_lid_bone)

                    # look direction offset
                    f_bone = rig.pose.bones.get('eye.{}'.format(side))
                    offset = _get_bone_delta(bone, f_bone)

                    # apply offset to the bone
                    new_pos = bone.matrix.translation - vec * .1 - offset * 0.01
                    bone.matrix.translation = new_pos
                    bone.keyframe_insert(data_path='location', frame=frame)

        scene.frame_current = scene.frame_start
        return {'FINISHED'}
