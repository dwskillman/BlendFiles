import bpy
import json
from math import floor
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata


class FACEIT_OT_PopulateProps(bpy.types.Operator):
    '''Use to populate the expression list'''
    bl_idname = 'faceit.init_anim_props'
    bl_label = 'Populate Animation properties'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        if futils.get_object('FaceitRig'):
            return True

    def execute(self, context):
        scene = context.scene

        # remove previous entries
        expression_list = scene.faceit_expression_list
        expression_list.clear()

        with open(fdata.get_expressions_file()) as f:
            data = json.load(f)
            expressions_dict = data['ARKIT']['Indices']
            for expression, index in expressions_dict.items():

                frame = int(index+1)*10

                item = expression_list.add()
                item.name = expression
                item.frame = frame
                item.index = index

                if 'Left' in expression:
                    item.side = 'L'
                    item.mirror_name = expression.replace('Left', 'Right')
                elif 'Right' in expression:
                    item.side = 'R'
                    item.mirror_name = expression.replace('Right', 'Left')
                else:
                    item.side = 'N'
                    item.mirror_name = ''

        return{'FINISHED'}


def set_pose_from_timeline(context):
    scene = context.scene
    shape_index = scene.faceit_expression_list_index
    if scene.faceit_expression_list[shape_index].frame != scene.frame_current:
        frame = scene.frame_current
        new_index = floor(frame / 10)  # shapes animation every 10 frames
        if frame % 10 == 0:
            new_index = new_index - 1
        scene.faceit_expression_list_index = new_index


class FACEIT_OT_GoToFrame(bpy.types.Operator):
    '''Snap Timeline Cursor to the nearest Expression'''
    bl_idname = 'faceit.set_timeline'
    bl_label = 'Snap Timeline Cursor to Expression'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        current_expression = scene.faceit_expression_list[scene.faceit_expression_list_index]
        if futils.get_object('FaceitRig') and current_expression.frame != scene.frame_current:
            return True

    def execute(self, context):

        set_pose_from_timeline(context)

        return{'FINISHED'}


class FACEIT_OT_ResetFrame(bpy.types.Operator):
    '''Reset Pose to the originally generated Pose'''
    bl_idname = 'faceit.shape_reset'
    bl_label = 'Reset Expression'
    bl_options = {'UNDO', 'INTERNAL'}

    expression_to_reset: bpy.props.StringProperty(
        name='Expression to Reset',
        default='ALL'
    )

    @classmethod
    def poll(cls, context):
        if context.object == futils.get_object('FaceitRig'):
            return True

    def execute(self, context):
        scene = context.scene
        expression_list = scene.faceit_expression_list
        curr_expression = scene.faceit_expression_list_index
        if self.expression_to_reset == 'ALL':
            expressions_operate = expression_list
        else:
            expressions_operate = [expression_list[self.expression_to_reset]]
        for exp in expressions_operate:
            frame = exp.frame
            scene.frame_current = frame

            futils.reset_key_frame(context, frame)

        scene.faceit_expression_list_index = curr_expression
        return{'FINISHED'}


class FACEIT_OT_MirrorOverwriteAnimation(bpy.types.Operator):
    '''Mirror the selected Expression to the opposite side (onyl L and R expressions)'''
    bl_idname = 'faceit.mirror_overwrite'
    bl_label = 'Mirror Expression'

    expression_to_mirror: bpy.props.StringProperty(
        name='Expression to Mirror',
        default='ACTIVE',
    )

    @classmethod
    def poll(cls, context):
        rig = futils.get_object('FaceitRig')
        if rig is not None:
            if context.active_object == rig and rig.hide_viewport == False:
                return True

    def execute(self, context):
        # create additive or overwrite animation
        scene = context.scene
        mode_save = context.mode
        if context.mode != 'POSE':
            bpy.ops.object.mode_set(mode='POSE')

        expression_index = scene.faceit_expression_list_index
        expression_list = scene.faceit_expression_list

        if self.expression_to_mirror == 'ALL':
            expressions_to_mirror = expression_list
        elif self.expression_to_mirror == 'ACTIVE':
            set_pose_from_timeline(context)
            active_expression = expression_list[expression_index]
            if active_expression.mirror_name == '':
                self.report({'WARNING'}, 'The expression you are trying to mirror is not Left or Right side')
                return{'CANCELLED'}
            else:
                expressions_to_mirror = [active_expression]
        else:
            expressions_to_mirror = [expression_list[self.expression_to_mirror]]
        for exp in expressions_to_mirror:
            if exp.mirror_name:
                mirror_expression = expression_list[exp.mirror_name]
                bpy.ops.pose.select_all(action='SELECT')
                futils.mirror_key_frame(context, exp.frame, mirror_expression.frame)
                bpy.ops.pose.select_all(action='DESELECT')
                new_index = mirror_expression.index

        scene.faceit_expression_list_index = new_index

        bpy.ops.object.mode_set(mode=mode_save)
        return{'FINISHED'}
