import bpy
from mathutils import Vector
from bpy_extras import view3d_utils
from . import faceit_utils as futils
from .faceit_data import faceit_data as fdata


class FACEIT_OT_FacialLandmarks(bpy.types.Operator):
    '''
imports the facial landmark reference and starts the interactive fitting process
1 - set the facial position to chin
2/3 - set width/height of landmark mesh
3 - refine positions by editting the landmarks mesh
    '''

    bl_idname = 'faceit.facial_landmarks'
    bl_label = 'facial_landmarks'
    bl_options = {'UNDO', 'INTERNAL'}

    # @state : the state of landmark fitting
    state: bpy.props.IntProperty(default=0)

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return futils.get_main_faceit_object()

    def __init__(self):
        # for right/left click query
        self.mouse_select = None
        self.mouse_deselect = None
        # safety counter needed as a workaround for multitrigger events
        self.safety_timer = 3
        # initial cursor position to scale with mouse movement
        self.initial_mouse_scale = 0
        # to check if the scale has been initialized
        self.set_init_scale = False
        # the initial dimensions used abort scaling operation
        self.initial_dimensions = (0, 0, 0)

    def execute(self, context):

        scene = context.scene
        if context.object:
            bpy.ops.object.mode_set(mode='OBJECT')

        # create the collection that holds faceit objects
        faceit_collection = bpy.data.collections.get('Faceit_Collection')
        if not faceit_collection:
            faceit_collection = bpy.data.collections.new(name='Faceit_Collection')
            scene.collection.children.link(faceit_collection)

        futils.clear_object_selection()
        futils.set_active_object(scene.faceit_object_name)
        # frame the object to be rigged
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                override = context.copy()
                override['area'] = area
                bpy.ops.view3d.view_selected(use_all_regions=False)
                bpy.ops.view3d.view_axis(override, type='FRONT')
                shading = area.spaces.active.shading
                shading.type = 'SOLID'
                shading.show_xray = False
                shading.show_xray_wireframe = False
                break

        # load the landmarks object
        filepath = fdata.get_landmarks_file()

        # load the objects data in the file
        with bpy.data.libraries.load(filepath) as (data_from, data_to):
            data_to.objects = data_from.objects

        # add the objects in the scene
        for obj in data_to.objects:
            if obj.type == 'MESH':
                if scene.faceit_asymmetric:
                    if obj.name == 'facial_landmarks_asymmetric':
                        faceit_collection.objects.link(obj)
                        lm_obj = futils.get_object('facial_landmarks_asymmetric')
                    else:
                        bpy.data.objects.remove(obj)
                else:
                    if obj.name == 'facial_landmarks':
                        faceit_collection.objects.link(obj)
                        lm_obj = futils.get_object('facial_landmarks')
                    else:
                        bpy.data.objects.remove(obj)
        lm_obj.name = 'facial_landmarks'

        futils.clear_object_selection()
        futils.set_active_object(lm_obj.name)

        # initialize the state prop
        if lm_obj:
            if not hasattr(lm_obj, '["state"]'):
                lm_obj['state'] = self.state

        self.reset_scale(context)

        return {'FINISHED'}

    def reset_scale(self, context):
        obj = futils.get_object('facial_landmarks')
        face_obj = futils.get_main_faceit_object()

        if hasattr(obj, '["state"]'):
            if obj['state'] == 0:
                obj.dimensions[2] = face_obj.dimensions[2]/2
                obj.scale = [obj.scale[2], obj.scale[2], obj.scale[2]]
            else:
                mw = face_obj.matrix_world
                # get the global coordinates
                global_v_co = [mw @ v.co for v in face_obj.data.vertices]
                # get the highest point in head mesh (temple)
                v_highest = max([co.z for co in global_v_co])
                # get distance from chin to temple
                head_height = obj.location[2] - v_highest
                # apply scale
                obj.dimensions[2] = head_height
                obj.scale = [obj.scale[2], obj.scale[2], obj.scale[2]]

    def set_face_pos(self, context, event):
        obj = futils.get_object('facial_landmarks')
        if not obj:
            return
        _region = context.region
        _region_3d = context.space_data.region_3d
        coord = 0, event.mouse_region_y
        obj.location = view3d_utils.region_2d_to_location_3d(_region, _region_3d, coord, obj.location)
        obj.location[0] = 0
        obj.location[1] = 0

    def set_face_scale(self, context, event, axis=2):

        obj = bpy.data.objects.get('facial_landmarks')
        if obj == None:
            return

        region = context.region
        rv3d = context.region_data
        coord = event.mouse_region_x, event.mouse_region_y

        _region = context.region
        _region_3d = context.space_data.region_3d
        mouse_pos = view3d_utils.region_2d_to_origin_3d(_region, rv3d, coord)

        # initialize reference scale
        if not self.set_init_scale:
            # get the initial dimensions before altering - used to reset
            self.initial_dimensions = obj.dimensions[:]
            # set the initial relative mouse position for scaling
            self.initial_mouse_scale = mouse_pos[axis] - obj.dimensions[axis]

            self.set_init_scale = True

        # get the distance from initial mouse
        face_dim = mouse_pos[axis] - self.initial_mouse_scale
        # apply the dimension on x axis
        obj.dimensions[axis] = face_dim

    # modal operations depending on current state
    def modal(self, context, event):
        obj = futils.get_object('facial_landmarks')
        if not obj:
            self.report({'WARNING'}, 'No landmarks object, could not finish')
            return {'CANCELLED'}

        # safety counter needed as a workaround for multitrigger events
        if self.safety_timer >= 0:
            self.safety_timer = self.safety_timer - 1

        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:  # 'MIDDLEMOUSE'
            # allow navigation
            return {'PASS_THROUGH'}

        # modal operations: move, scale height, scale width
        if event.type == 'MOUSEMOVE':
            if obj['state'] == 0:
                self.set_face_pos(context, event)
            elif obj['state'] == 1:
                self.set_face_scale(context, event, axis=2)
            elif obj['state'] == 2:
                self.set_face_scale(context, event, axis=0)

        # go into next state / finish
        elif event.type == self.mouse_select and event.value == 'RELEASE':

            if obj['state'] == 0:
                obj['state'] = 1
                self.set_init_scale = False
                # scale to the right dimensions:
                self.reset_scale(context)
                futils.set_active_object(obj.name)
                # frame the object to be rigged
                for area in bpy.context.screen.areas:
                    if area.type == 'VIEW_3D':
                        override = context.copy()
                        override['area'] = area
                        bpy.ops.view3d.view_selected(use_all_regions=False)
                        bpy.ops.view3d.view_axis(override, type='FRONT')
                        break
                self.safety_timer = 3

            if obj['state'] == 1 and self.safety_timer <= 0:
                self.set_init_scale = False
                obj['state'] = 2
                self.safety_timer = 3

            if obj['state'] == 2 and self.safety_timer <= 0:
                final_mat = obj.matrix_world
                obj.matrix_world = final_mat
                futils.set_active_object(obj.name)
                obj['state'] = 3
                # get the vertex size user settings - reset after face adaption
                context.scene.faceit_vertex_size = bpy.context.preferences.themes[0].view_3d.vertex_size
                # Make big vertices
                bpy.context.preferences.themes[0].view_3d.vertex_size = 8
                # enable vertex selection only
                bpy.context.tool_settings.mesh_select_mode = (True, False, False)
                bpy.ops.object.mode_set(mode='EDIT')
                return {'FINISHED'}

        # go into previous state / cancel
        elif event.type in {self.mouse_deselect, 'ESC'} and event.value == 'RELEASE':
            bpy.ops.object.mode_set(mode='OBJECT')
            if self.safety_timer <= 0:
                if obj['state'] == 0:
                    bpy.data.objects.remove(obj)
                    return {'CANCELLED'}
                if obj['state'] == 2:
                    self.set_init_scale = False
                if obj['state'] > 0:
                    obj['state'] = obj['state'] - 1
                self.safety_timer = 3

        context.area.tag_redraw()

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.execute(context)

        # first time launch
        # get mouse selection from user pref
        self.mouse_deselect = 'RIGHTMOUSE'
        self.mouse_select = 'LEFTMOUSE'

        if futils.get_mouse_select() == 'RIGHT':
            self.mouse_select = 'RIGHTMOUSE'
            self.mouse_deselect = 'LEFTMOUSE'

        self.set_face_pos(context, event)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class FACEIT_OT_ResetFacial(bpy.types.Operator):
    '''	Discard Landmarks and start over '''
    bl_idname = 'faceit.reset_facial_landmarks'
    bl_label = 'Reset Landmarks'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(self, context):
        # if bpy.data.objects.get('facial_landmarks'):
        return True

    def execute(self, context):
        obj = futils.get_object('facial_landmarks')
        # delete face
        if obj != None:
            bpy.data.objects.remove(obj)

        context.preferences.themes[0].view_3d.vertex_size = context.scene.faceit_vertex_size
        return {'FINISHED'}


class FACEIT_OT_ProjectFacial(bpy.types.Operator):
    '''Project facial markers '''
    bl_idname = 'faceit.facial_project'
    bl_label = 'Project Landmarks'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(self, context):
        if bpy.data.objects.get('facial_landmarks'):
            return True

    def get_far_point(self, obj, direction):
        # world matrix
        mat = obj.matrix_world
        far_distance = 0
        far_point = direction

        for v in obj.data.vertices:
            point = mat @ v.co
            temp = direction.dot(point)
            # new high?
            if far_distance < temp:
                far_distance = temp
                far_point = point
        return far_point

    def execute(self, context):

        scene = context.scene

        proj_obj = futils.get_object('facial_landmarks')
        if proj_obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        # duplicate the object
        bpy.ops.object.select_all(action='DESELECT')
        futils.set_active_object(proj_obj.name)

        # get the face object
        surface_obj = bpy.data.objects[context.scene.faceit_object_name]
        # move in front of face
        if surface_obj:
            proj_obj.location.y = self.get_far_point(
                obj=surface_obj, direction=Vector((0, -1, 0)))[1] - proj_obj.dimensions[1]
        else:
            self.report({'ERROR'}, 'Faceit was not able to find a MAIN object. Did you register it properly?')
            return{'CANCELLED'}

        futils.set_active_object(proj_obj.name)
        # projection modifier
        mod = proj_obj.modifiers.new(name='ShrinkWrap', type='SHRINKWRAP')
        mod.target = surface_obj
        mod.wrap_method = 'PROJECT'
        mod.use_project_y = True
        mod.use_positive_direction = True
        mod.show_on_cage = True
        # apply the modifier
        bpy.ops.object.modifier_apply(modifier=mod.name)

        # go to edit mode and refine the positions
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        scene.tool_settings.use_snap = True
        scene.tool_settings.snap_elements = {'FACE'}
        scene.tool_settings.snap_target = 'CLOSEST'
        scene.tool_settings.use_snap_project = True

        # Go to Side view
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                override = bpy.context.copy()
                override['area'] = area
                bpy.ops.view3d.view_selected(use_all_regions=False)
                bpy.ops.view3d.view_axis(override, type='RIGHT')
                break

        # state update - mode change required to log state update in undo history
        bpy.ops.object.mode_set(mode='OBJECT')
        proj_obj['state'] = 4
        chin_vert = 0 if scene.faceit_asymmetric else 1
        obj_origin = proj_obj.matrix_world @ proj_obj.data.vertices[chin_vert].co
        context.scene.cursor.location = obj_origin
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


class FACEIT_OT_MirrorSelectedVerts(bpy.types.Operator):
    '''Mirror selected Landmarks Vertices - In case MirrorX fails'''
    bl_idname = 'faceit.mirror_selected_verts'
    bl_label = 'Mirror Selected Vertices'
    bl_options = {'UNDO', 'INTERNAL', 'REGISTER'}

    mirror_dir: bpy.props.EnumProperty(
        items=[
            ('L_R', 'Left to Right', 'left to right side mirror (x+ -> x-)'),
            ('R_L', 'Right to Left', 'right to left side mirror (x- -> x+)'),
        ],
        name='Mirror Direction'
    )

    @classmethod
    def poll(self, context):
        if context.object.name == 'facial_landmarks' and context.mode == 'EDIT_MESH':
            return True

    def execute(self, context):

        obj = futils.get_object('facial_landmarks')
        bpy.ops.object.mode_set(mode='OBJECT')
        mirror_dict = fdata.landmarks_mirror_vertices_dict
        m_world = obj.matrix_world
        m_loc = m_world.inverted()

        left_verts_indices = mirror_dict.keys()
        left_verts = [v for v in obj.data.vertices if v.index in left_verts_indices]
        right_verts_indices = mirror_dict.values()
        right_verts = [v for v in obj.data.vertices if v.index in right_verts_indices]
        selected_verts = [v for v in obj.data.vertices if v.select]

        # print('{}\n'.format(left_verts))
        # print('{}\n'.format(selected_verts))
        if all(v in left_verts for v in selected_verts):  # any([v in left_verts for v in selected_verts]):
            self.mirror_dir = 'L_R'
        elif all(v in right_verts for v in selected_verts):
            self.mirror_dir = 'R_L'
        else:
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'WARNING'}, 'Select either Left or Right Side Vertices')
            return{'FINISHED'}

        for left_vert, right_vert in zip(left_verts, right_verts):
            if self.mirror_dir == 'L_R':
                if not left_vert.select:
                    continue
                mirror_co = left_vert.co @ m_world
                mirror_co[0] = mirror_co[0] * -1
                right_vert.co = mirror_co @ m_loc
            else:
                if not right_vert.select:
                    continue
                mirror_co = right_vert.co @ m_world
                mirror_co[0] = mirror_co[0] * -1
                left_vert.co = mirror_co @ m_loc

        bpy.ops.object.mode_set(mode='EDIT')
        return{'FINISHED'}
