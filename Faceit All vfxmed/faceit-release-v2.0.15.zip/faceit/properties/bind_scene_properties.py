from bpy.types import Scene
from bpy.props import BoolProperty, EnumProperty

# --------------- CLASSES --------------------
# | - Property Groups (Collection-/PointerProperty)
# ----------------------------------------------


# --------------- FUNCTIONS --------------------
# | - Update/Getter/Setter
# ----------------------------------------------


# --------------- REGISTER/UNREGISTER --------------------
# |
# --------------------------------------------------------


def register():

    Scene.faceit_weights_restorable = BoolProperty(
        default=False,
    )
    Scene.faceit_expressions_restorable = BoolProperty(
        default=False,
    )
    Scene.faceit_corrective_sk_restorable = BoolProperty(
        default=False,
    )


def unregister():
    del Scene.faceit_weights_restorable
    del Scene.faceit_expressions_restorable
    del Scene.faceit_corrective_sk_restorable
