import bpy
from bpy.types import Panel
from addon_utils import check

from . import draw_utils
from . import retarget_fbx_ui


class FACEIT_PT_Deltas():
    bl_label = "Deltas"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'


class FACEIT_PT_DeltaTransformHead(FACEIT_PT_Deltas, Panel):
    bl_label = "Delta Transformation Head"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_head)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")


class FACEIT_PT_DeltaTransformEyeLeft(FACEIT_PT_Deltas, Panel):
    bl_label = "Delta Transformation Eye Left"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_eye_l)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")


class FACEIT_PT_DeltaTransformEyeRight(FACEIT_PT_Deltas, Panel):
    bl_label = "Delta Transformation Eye Right"

    @classmethod
    def poll(cls, context):
        return (context.scene.faceit_mocap_target_head is not None)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        scene = context.scene

        ob = scene.objects.get(scene.faceit_mocap_target_eye_r)

        col = layout.column()
        # col.prop(ob, 'name')
        col.prop(ob, "delta_location", text="Location")

        rotation_mode = ob.rotation_mode
        if rotation_mode == 'QUATERNION':
            col.prop(ob, "delta_rotation_quaternion", text="Rotation")
        elif rotation_mode == 'AXIS_ANGLE':
            pass
        else:
            col.prop(ob, "delta_rotation_euler", text="Rotation")


class SHAPE_AMPLIFY_MOCAP_UL_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):

        if self.layout_type in {'DEFAULT', 'COMPACT'}:

            row = layout.row(align=True)

            if item.use_animation == True:
                icon = 'CHECKBOX_HLT'
            else:
                icon = 'CHECKBOX_DEHLT'

            row.prop(item, 'use_animation', text='', expand=False, icon=icon)

            target_shapes = item.target_shapes
            row.active = expression_enabled = item.use_animation and len(target_shapes) > 0

            if expression_enabled:
                row.prop(item, 'amplify', emboss=True, text=item.name)
            else:
                row.prop(item, 'amplify', emboss=False, text=item.name)


def draw(context, layout):
    scene = context.scene

    col_mocap = layout.column()

    box = col_mocap.box()

    row = box.row()
    draw_utils.draw_panel_dropdown_expander(row, scene, 'faceit_mocap_general_expand_ui', 'Mocap Settings')
    draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/arkit_setup/#general-mocap-settings')

    if scene.faceit_mocap_general_expand_ui:

        box_action = box.box()
        col = box_action.column(align=True)
        row = col.row(align=True)

        draw_utils.draw_panel_dropdown_expander(row, scene, 'faceit_mocap_action_expand_ui', 'Action')
        if scene.faceit_mocap_action_expand_ui:
            row = col.row(align=True)
            row.prop(scene, 'faceit_mocap_action', text='')
            op = row.operator('faceit.populate_action', icon='ACTION_TWEAK')
            row = col.row(align=True)
            row.operator('faceit.new_action', icon='ADD')

        box_targets = box.box()
        col = box_targets.column(align=True)
        row = col.row()
        motion_types_setup = scene.faceit_mocap_motion_types
        draw_utils.draw_panel_dropdown_expander(
            row, motion_types_setup, 'expand', 'Motion Types (Experimental)')
        # row.label(text = 'Targets')
        # Property Group holding Face Cap Settings
        if motion_types_setup.expand:
            row = col.row(align=True)
            row.prop(motion_types_setup, 'blendshapes_target', icon='SHAPEKEY_DATA')
            row = col.row(align=True)
            row.prop(motion_types_setup, 'head_target_rotation', icon='CON_ROTLIKE')
            row.prop(motion_types_setup, 'eye_target_rotation', icon='CON_ROTLIKE')
            # row.prop(motion_types_setup, 'head_target_location', icon='ORIENTATION_VIEW')

            if motion_types_setup.head_target_rotation:

                col.separator()

                row = col.row(align=True)
                op = row.operator('faceit.face_cap_empty', text='Create Head Target')
                op.face_cap_empty = 'HEAD'
                row = col.row(align=True)
                row.prop_search(scene, 'faceit_mocap_target_head', bpy.data, 'objects', text='')
                op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                op_populate.face_cap_empty = 'HEAD'
                obj = scene.objects.get(scene.faceit_mocap_target_head)
                if obj:
                    row = col.row(align=True)
                    row.popover('FACEIT_PT_DeltaTransformHead')

            if motion_types_setup.eye_target_rotation:

                col.separator()

                row = col.row(align=True)
                op = row.operator('faceit.face_cap_empty', text='Create Eye Targets')
                op.face_cap_empty = 'EYES'
                row = col.row(align=True)
                row.prop_search(scene, 'faceit_mocap_target_eye_l', bpy.data, 'objects', text='')
                op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                op_populate.face_cap_empty = 'EYE_L'

                row.prop_search(scene, 'faceit_mocap_target_eye_r', bpy.data, 'objects', text='')
                op_populate = row.operator('faceit.populate_face_cap_empty', text='', icon='EYEDROPPER')
                op_populate.face_cap_empty = 'EYE_R'
                obj = scene.objects.get(
                    scene.faceit_mocap_target_eye_r) or scene.objects.get(
                    scene.faceit_mocap_target_eye_l)
                if obj:
                    row = col.row(align=True)
                    row.popover('FACEIT_PT_DeltaTransformEyeLeft')
                    row.popover('FACEIT_PT_DeltaTransformEyeRight')

    retarget_fbx_ui.draw(context, col_mocap)

    box = col_mocap.box()
    col = box.column(align=True)

    face_cap_mocap_settings = scene.faceit_face_cap_mocap_settings

    row = col.row()
    draw_utils.draw_panel_dropdown_expander(row, face_cap_mocap_settings, 'master_expanded', 'Face Cap')

    if face_cap_mocap_settings.master_expanded:

        col.separator(factor=2.0)
        box_fbx = col.box()
        col_fbx = box_fbx.column()
        col_fbx.label(text='(See FBX Retargeting above)',)  # icon='TRIA_UP')
        col.separator(factor=1.0)

        box_live = col.box()
        col_live = box_live.column()
        row = col_live.row()

        draw_utils.draw_panel_dropdown_expander(
            row, face_cap_mocap_settings, 'live_mode_expanded', 'LIVE Mocap')
        draw_utils.draw_web_link(
            row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#live-capturing-osc')
        if face_cap_mocap_settings.live_mode_expanded:

            if check(module_name="AddRoutes")[1]:
                row = col_live.row(align=True)
                row.operator('faceit.add_routes')
                row = col_live.row(align=True)
                row.operator('faceit.clear_routes')
                if not scene.MOM_Items:
                    row.enabled = False

                row = col_live.row(align=True)
                row.prop(scene, 'faceit_record_face_cap', text='Record', icon='REC')
                if not scene.MOM_Items:
                    row.enabled = False
            else:
                row = col_live.row(align=True)
                draw_utils.draw_web_link(
                    row,
                    'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#addroutes-add-on',
                    text_ui='Install AddRoutes First...', show_always=True)

        col.separator(factor=1.0)

        box_txt = col.box()
        row = box_txt.row()

        draw_utils.draw_panel_dropdown_expander(
            row, face_cap_mocap_settings, 'file_import_expanded', 'TXT Import')
        draw_utils.draw_web_link(
            row, 'https://faceit-doc.readthedocs.io/en/latest/face_cap_utils/#load-recorded-motion-txt')

        if face_cap_mocap_settings.file_import_expanded:

            row = box_txt.row(align=True)
            row.prop(face_cap_mocap_settings, 'filename', text='')
            op = row.operator('faceit.custom_path', text='Load FaceCap TXT', icon='FILE_FOLDER')
            op.engine = 'FACECAP'

            col_txt = box_txt.column()

            row = col_txt.row(align=True)
            # row.prop(face_cap_mocap_settings, 'load_to_new_action', icon='ACTION_TWEAK')
            # if not face_cap_mocap_settings.load_to_new_action:
            #     row.prop(scene, 'faceit_mocap_action', text='')

            row = col_txt.row(align=True)
            row.operator_context = 'INVOKE_DEFAULT'

            # row.prop(face_cap_mocap_settings, 'frame_start')
            op = row.operator('faceit.import_mocap', icon='IMPORT')
            op.engine = 'FACECAP'

            col_txt.enabled = (face_cap_mocap_settings.filename != '')

        # retarget_fbx_ui.draw(context, col)

    ######################## EPIC Live Link Face ##################################
    ue_mocap_settings = scene.faceit_epic_mocap_settings

    box_ue = col_mocap.box()
    row = box_ue.row()
    draw_utils.draw_panel_dropdown_expander(row, ue_mocap_settings, 'master_expanded', 'Live Link Face')

    if ue_mocap_settings.master_expanded:

        box_txt = box_ue.box()
        row = box_txt.row()

        draw_utils.draw_panel_dropdown_expander(row, ue_mocap_settings, 'file_import_expanded', 'CSV Import')
        draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/epic_utils/')

        if ue_mocap_settings.file_import_expanded:

            row = box_txt.row(align=True)
            row.prop(ue_mocap_settings, 'filename', text='')
            op = row.operator('faceit.custom_path', text='Load UE4 CSV', icon='FILE_FOLDER')
            op.engine = 'EPIC'

            col_txt = box_txt.column()
            # row = col_txt.row(align=True)
            # row.prop(ue_mocap_settings, 'load_to_new_action', icon='ACTION_TWEAK')
            # if not ue_mocap_settings.load_to_new_action:
            #     row.prop(scene, 'faceit_mocap_action', text='')

            row = col_txt.row(align=True)
            row.operator_context = 'INVOKE_DEFAULT'

            # row.prop(ue_mocap_settings, 'frame_start')
            op = row.operator('faceit.import_mocap', icon='IMPORT')
            op.engine = 'EPIC'

            col_txt.enabled = (ue_mocap_settings.filename != '')
