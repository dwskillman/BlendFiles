from bpy.types import Panel

from . import draw_utils
from . import bake_panel
from . import setup_panel
from . import mocap_panel
from . import c_rig_panel
from . import shapes_panel
from . import rigging_panel
from . import expresssions_panel
from ..core import faceit_utils as futils


class FACEIT_PT_MainPanel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'FACEIT'
    bl_label = 'FaceIt'

    def draw(self, context):

        # current_version = fdata.get_faceit_current_version()

        scene = context.scene

        layout = self.layout

        landmarks_obj = futils.get_object('facial_landmarks')

        box = layout.box()
        row = box.row()
        faceit_workspace = scene.faceit_workspace

        draw_utils.draw_panel_dropdown_expander(row, faceit_workspace, 'expand_ui', 'Choose Workspace')

        if faceit_workspace.expand_ui:
            box.row().prop(faceit_workspace, 'workspace', expand=True, icon='CUBE')

        active_tab = faceit_workspace.active_tab
        layout.row().prop(faceit_workspace, 'active_tab', expand=True)

        layout.separator()

        if scene.faceit_use_rigify_armature:
            rig = futils.get_faceit_armature()
        else:
            rig = futils.get_faceit_armature(force_original=True)

        c_rig = futils.get_faceit_control_armature()

        ############ SETUP ################
        if active_tab == 'SETUP':

            setup_panel.draw(context, layout)

        ############ RIGGING ################

        if active_tab == 'CREATE':

            rigging_panel.draw(context, layout, landmarks_obj, rig)

        ############ ADAPTION ################

        if active_tab == 'ADAPT':
            expresssions_panel.draw(context, layout, landmarks_obj, rig)

        ############ BAKING ################

        if active_tab == 'BAKE':
            bake_panel.draw(context, layout, rig)

        ############ MOCAP ################

        if active_tab == 'MOCAP':
            mocap_panel.draw(context, layout)

        ############ SHAPES ################

        if active_tab == 'SHAPES':
            shapes_panel.draw(context, layout)

        ############ CONTROL RIG ################

        if active_tab == 'CONTROL':
            c_rig_panel.draw(context, layout, c_rig, landmarks_obj)
