import bpy
from . import draw_utils


def draw(context, layout, rig):

    scene = context.scene

    col = layout.column(align=True)

    col.use_property_split = True
    col.use_property_decorate = False

    row = col.row()
    row.label(text='Bake and Finalize')

    draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/bake/')

    col.separator()

    if context.scene.faceit_shapes_generated:
        row = col.row(align=True)
        row.operator('faceit.reset_to_rig', icon='BACK')

    row = col.row(align=True)
    row.operator('faceit.generate_shapekeys', icon='USER')

    col.separator(factor=1)
    row = col.row(align=True)
    row.alert = True

    # if not scene.faceit_face_objects:
    #     op = row.operator('faceit.go_to_tab', text='Complete Setup First...')
    #     op.tab = 'SETUP'

    # elif not rig:
    #     op = row.operator('faceit.go_to_tab', text='Generate Rig First...')
    #     op.tab = 'CREATE'

    # elif rig and not scene.faceit_shapes_generated:
    #     if not futils.get_faceit_armature_modifier(futils.get_main_faceit_object()):
    #         op = row.operator('faceit.go_to_tab', text='Bind Rig First...')
    #         op.tab = 'CREATE'

    box = layout.box()
    row = box.row()

    draw_utils.draw_panel_dropdown_expander(row, scene, 'faceit_shape_key_utils_expand_ui', '   Shape Key Utils')
    draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/utils/#shape-key-utils')

    # draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/workaround/')

    if scene.faceit_shape_key_utils_expand_ui:

        col = box.column()
        col.use_property_split = True
        col.use_property_decorate = False

        if not scene.faceit_face_objects:
            row = box.row()
            row.alert = True
            op = row.operator('faceit.go_to_tab', text='Complete Setup First...')
            op.tab = 'SETUP'
            col.enabled = False
        else:
            col.enabled = True

        col.separator()

        row = col.row(align=True)
        row.label(text='Set Shape Key Slider Range')

        row = col.row()
        sub = row.column(align=True)
        # sk_options = scene.faceit_shape_key_options
        sub.prop(scene, 'faceit_shape_key_slider_min', text='Range Min')
        sub.prop(scene, 'faceit_shape_key_slider_max', text='Max')

        row = col.row(align=True)
        row.operator('faceit.set_shape_key_range')

        row = col.row(align=True)
        row.label(text='Indices')
        row = col.row(align=True)
        row.operator('faceit.reorder_keys', icon='SHAPEKEY_DATA')

        row = col.row(align=True)
        row.label(text='Testing')
        row = col.row(align=True)
        row.operator('faceit.test_action', icon='ACTION')
        # col.separator()

    box = layout.box()
    row = box.row()

    draw_utils.draw_panel_dropdown_expander(row, scene, 'faceit_finalize_utils_expand_ui', 'Finalize (Destructive)')
    draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/utils/#finalize')

    if scene.faceit_finalize_utils_expand_ui:
        col = box.column()

        # row = col.row(align=True)
        # row.label(text='Finalize (Destructive)')
        row = col.row(align=True)
        row.operator('faceit.cleanup_objects', icon='TRASH')
        row = col.row(align=True)
        row.operator('faceit.cleanup_scene', icon='TRASH')
        row = col.row(align=True)
        row.operator('faceit.clear_all_corrective_shapes', icon='SHAPEKEY_DATA').expression = 'ALL'

    box = layout.box()
    row = box.row()
    draw_utils.draw_panel_dropdown_expander(row, scene, 'faceit_other_utilities_expand_ui', 'Other Utils')
    draw_utils.draw_web_link(row, 'https://faceit-doc.readthedocs.io/en/latest/utils/#other')

    if scene.faceit_other_utilities_expand_ui:
        col = box.column()

        # row = col.row(align=True)
        # row.label(text='Fixes')
        row = col.row(align=True)
        row.label(text='Apply Modifiers')

        row = col.row(align=True)
        row.operator('faceit.apply_modifier_object_with_shape_keys', icon='SHAPEKEY_DATA')

        row = col.row(align=True)
        row.label(text='Set Theme Vertex Size')
        row = col.row(align=True)

        sub = row.split(factor=.9, align=True)
        # bpy.context.preferences.themes[0].view_3d.vertex_size
        sub.prop(bpy.context.preferences.themes[0].view_3d, 'vertex_size')
        sub.operator('faceit.set_theme_vertex_size', text='3').vertex_size = 3
        sub.operator('faceit.set_theme_vertex_size', text='8').vertex_size = 8
