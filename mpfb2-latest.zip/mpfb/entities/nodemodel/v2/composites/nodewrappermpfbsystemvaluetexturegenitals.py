import bpy, json

from .nodewrappermpfbsystemvaluetexture import NodeWrapperMpfbSystemValueTexture

class _NodeWrapperMpfbSystemValueTextureGenitals(NodeWrapperMpfbSystemValueTexture):
    def __init__(self):
        NodeWrapperMpfbSystemValueTexture.__init__(self, "mpfb_genitals.jpg", "NodeWrapperMpfbSystemValueTextureGenitals")

NodeWrapperMpfbSystemValueTextureGenitals = _NodeWrapperMpfbSystemValueTextureGenitals()
